package ar.org.centro8.curso.java.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.curso.java.models.entities.Alumno;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_AlumnoRepository;

/**
 * Clase de servicio para la entidad Alumno
 * Encapsula todas la lógica de negocio relacionada con alumnos.
 * Actúa como un intermediario entre los controladores y los repositorios,
 * asegurando que los controladores sean "delgados" y que la lógica de negocio
 * sea reutilizable y probada en forma aislada.
 */
@Service
public class AlumnoService {
    private final I_AlumnoRepository alumnoRepository;

    public AlumnoService(I_AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    /**
     * Obtiene una lista de todos los alumnos.
     * Acá se podría añadir lógica de negocio adicional, antes o después de la llamada
     * al repositorio. Como validaciones de permisos, filtros complejos que no son
     * gestionados por el repositorio, etc.
     * @return  Una lista con todos los alumnos.
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public List<Alumno> obtenerTodosLosAlumnos() throws SQLException{
        return alumnoRepository.findAll();
        //la lógica actual solo delega al repositorio
        //En un caso real, acá podríamos tener las validaciones, como si el usuario tiene
        //permiso para ver a todos los alumnos. O transformaciones de datos, por ejemplo
        //ocultar ciertos campos.
    }

}
