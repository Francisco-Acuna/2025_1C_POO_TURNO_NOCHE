package ar.org.centro8.curso.java.ejercicios;

public abstract class FiguraGeometrica {
    public abstract double getPerimetro();
    public abstract double getSuperficie();
}
