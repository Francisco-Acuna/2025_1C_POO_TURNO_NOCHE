package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.herencia.Cliente;
import ar.org.centro8.curso.java.entidades.herencia.Direccion;
import ar.org.centro8.curso.java.entidades.herencia.Empleado;
import ar.org.centro8.curso.java.entidades.herencia.Persona;
import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia:
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * La reconocemos con las palabras "es un/a".
         * Representa la relación más fuerte entre clases.
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es una subclase y la clase de la que deriva es la superclase.
         * También se las conoce como clase hija y clase padre.
         * Una clase en Java solo puede tener una herencia directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de la clase Direccion **");

        Direccion direccion1 = new Direccion("Av. Córdoba", 2135, "1", "sala 3");
        System.out.println(direccion1);

        Direccion direccion2 = new Direccion("Salta", 126, "2", "A");
        System.out.println(direccion2);
        
        System.out.println("**Clase Direccion funcionando correctamente**");

        System.out.println();

        /* System.out.println("**Test clase Persona**");

        Persona persona1 = new Persona("Mariana", "Juarez", 40, direccion1);
        System.out.println(persona1);
        persona1.saludar();

        System.out.println("**Clase Persona funcionando correctamente**"); */

        System.out.println("**Test de la clase Empleado**");
        
        Empleado empleado1 = new Empleado("Nicolás", "García", 20, direccion2, 120, 500000);
        System.out.println(empleado1);
        empleado1.saludar();

        System.out.println("**Clase Empleado funcionando correctamente**");

        System.out.println();

        System.out.println("**Test Clase Cliente**");

        Cuenta cuenta1 = new Cuenta(12, "Dólares");
        Cliente cliente1 = new Cliente("Juana", "Molina", 63, direccion2, 100, cuenta1);
        System.out.println(cliente1);

        System.out.println("**Clase Cliente funcionando correctamente**");

        System.out.println();

        // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

        /*
         * Polimorfismo
         * Es la capacidad de un objeto para tomar muchas formas, lo que permite que
         * el mismo método pueda comportarse de maneras diferentes dependiendo del contexto.
         * 
         * Hay dos clases de polimorfismo:
         * 
         * 1. Polimorfismo sin redefinición, es en tiempo de compilación (sobrecarga de métodos):
         *  Se produce cuando en una misma clase existen varios métodos con el mismo nombre
         *  pero con diferentes parámetros (diferentes firmas). Esto permite ejecutar acciones
         *  similares sobre distintos tipos o números de argumentos.
         * 
         * 2. Polimorfismo con redefinición, es en tiempo de ejecución (sobreescritura de métodos):
         *  Se produce cuando una subclase redefine un método heredado de la superclase (usando
         *  @Override). 
         *  Esto permite que una variable de tipo de la superclase pueda referenciar objetos de 
         *  diferentes sublcases, comportándose de manera distinta según la instancia correcta.
         */

        Persona persona1 = new Empleado("Leonardo", "DaVinci", 39, direccion2, 20, 1000);
        Persona persona2 = new Cliente("Dora", "Exploradora", 18, direccion1, 45460, cuenta1);

        persona1.saludar();
        persona2.saludar();

        System.out.println(persona1);
        System.out.println(persona2);

        // persona2.informarAlias();
        //el método informarAlias() no está declarado en la clase Cliente

        //modificar el ejercicio de las figuras geométricas para que
        //cumplan con el concepto de herencia

    }
}
