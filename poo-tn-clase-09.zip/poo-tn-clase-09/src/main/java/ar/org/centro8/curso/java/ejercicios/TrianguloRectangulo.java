package ar.org.centro8.curso.java.ejercicios;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class TrianguloRectangulo extends FiguraGeometrica{

    //atributos
    private double base;
    private double altura;

    @Override
    public double getPerimetro(){
        return base + altura + Math.hypot(base, altura);
    }

    @Override
    public double getSuperficie(){
        return (base * altura) / 2;
    }

}
