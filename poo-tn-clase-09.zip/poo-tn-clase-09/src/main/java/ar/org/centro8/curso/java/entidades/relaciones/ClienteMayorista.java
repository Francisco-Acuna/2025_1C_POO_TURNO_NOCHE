package ar.org.centro8.curso.java.entidades.relaciones;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ClienteMayorista {
    private int nroCliente;
    private String razonSocial;
    private String direccion;
    private List<Cuenta> cuentas;

    public ClienteMayorista(int nroCliente, String razonSocial, String direccion) {
        this.nroCliente = nroCliente;
        this.razonSocial = razonSocial;
        this.direccion = direccion;
        this.cuentas = new ArrayList<>(); //creamos una lista vacía
    }

    
}
