package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class EmpleadoAgregaciones {
    //Las agregaciones son un tipo de relación más fuerte entre clases.
    //Las reconocemos con las palabras "tiene un/a".
    //En este caso, un empleado tiene un auto.

    private int legajo;
    private String nombre;
    private String apellido;
    private Auto auto;

    //creamos un constructor sin el auto. El auto es parte de sus atributos
    //pero no lo asignamos de entrada
    public EmpleadoAgregaciones(int legajo, String nombre, String apellido) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    //con setAuto() asigno el auto al empleado
    

}
