package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter
@RequiredArgsConstructor
@ToString
public final class Cuenta {
    //al ser declarada como final, la clase no puede tener subclases o clases hijas

    private final int NUMERO_CUENTA;
    private final String MONEDA;
    private float saldo;
    
    public void depositar(float monto){
        this.saldo += monto;
    }

    public void debitar(float monto){
        if(saldo - monto < 0) System.out.println("Saldo insuficiente");
        else this.saldo -= monto;
    }
}
