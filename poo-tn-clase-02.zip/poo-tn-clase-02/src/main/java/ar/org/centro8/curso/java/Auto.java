package ar.org.centro8.curso.java;

public class Auto {
    //Una clase es una plantilla o molde que define los atributos y 
    //métodos que tendrán los objetos.

    //atributos
    //definimos los atributos o propiedades que son las variables
    //que representan las características
    String marca;
    String modelo;
    String color;
    int velocidad;



    //métodos
    //son bloques de código que definen el comportamiento de los objetos (acciones)
    void acelerar(){
        velocidad += 10;
    }

    void frenar(){
        velocidad -= 10;
    }

    //sobrecarga de métodos
    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Si el nitro es true, se incrementa el doble de kilómetros a la velocidad
     * @param kilometros = es la cantidad a acelerar
     * @param nitro = true si tiene nitro, false si no tiene
     */
    void acelerar(int kilometros, boolean nitro){
        if(nitro) velocidad += kilometros * 2;
        else velocidad += kilometros;
    }

    void frenar(int kilometros){
        if(velocidad-kilometros<0) velocidad = 0;
        else velocidad -= kilometros;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int obtenerVelocidad(){
        return velocidad;
    }


}
