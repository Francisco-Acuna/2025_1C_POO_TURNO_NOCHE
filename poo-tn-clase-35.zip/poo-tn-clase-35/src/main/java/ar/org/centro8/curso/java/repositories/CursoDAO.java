package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;

@Repository
public class CursoDAO implements I_CursoRepository{

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO cursos (titulo, profesor, dia, turno) VALUES (?,?,?,?)";
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM cursos WHERE id=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM cursos";
    private static final String SQL_UPDATE =
        "UPDATE cursos SET titulo=?, profesor=?, dia=?, turno=?, activo=? WHERE id=?";
    private static final String SQL_DELETE = 
        "DELETE FROM cursos WHERE id=?";
    private static final String SQL_FIND_BY_DIA_TURNO = 
        "SELECT * FROM cursos WHERE dia=? and turno=?";
    
    public CursoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Curso curso) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, curso.getTitulo());
            ps.setString(2, curso.getProfesor());
            ps.setString(3, curso.getDia().name()); //con name() obtengo el nombre de la constante
            ps.setString(4, curso.getTurno().name());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if(keys.next()){
                    curso.setId(keys.getInt(1));
                }
            } 
        } 
    }

    @Override
    public Curso findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if(rs.next()){
                    return mapRow(rs);
                }
            } 
        } 
        return null;
    }

    @Override
    public List<Curso> findAll() throws SQLException {
        List<Curso> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {
            while(rs.next()){
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Curso curso) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, curso.getTitulo());
            ps.setString(2, curso.getProfesor());
            ps.setString(3, curso.getDia().name());
            ps.setString(4, curso.getTurno().name());
            ps.setBoolean(5, curso.isActivo());
            ps.setInt(6, curso.getId());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Curso> findByDiaAndTurno(Dia dia, Turno turno) throws SQLException {
        List<Curso> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_DIA_TURNO)) {
            ps.setString(1, dia.name());
            ps.setString(2, turno.name());
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()){
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }

    private Curso mapRow(ResultSet rs) throws SQLException{
        Curso curso = new Curso();
        curso.setId(rs.getInt("id"));
        curso.setTitulo(rs.getString("titulo"));
        curso.setProfesor(rs.getString("profesor"));
        curso.setDia(Dia.valueOf(rs.getString("dia"))); //Dia.valueOf() convierte el String en una enum
        curso.setTurno(rs.getObject("turno", Turno.class)); //código más moderno para aplicaciones
        //actualizadas, JDBC 4.2 en adelante y JDK 8 en adelante
        curso.setActivo(rs.getBoolean("activo"));
        return curso;
    }

    


}
