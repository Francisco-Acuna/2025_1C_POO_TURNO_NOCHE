package ar.org.centro8.curso.java.tests;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.AlumnoDAO;
import ar.org.centro8.curso.java.repositories.CursoDAO;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;

/*
 * Esta clase utilizará el contexto de Spring Boot para obtener los DAOs y ejecutar operaciones.
 * Esta clase no es parte de la lógica de negocio de la aplicación en sí, sino una herramienta
 * para probar manualmente que nuestras capas de entidades y accesos a datos, funcionen correctamente.
 * Es como un banco de pruebas.
 * Necesitamos realizar las pruebas para asegurarnos de que todo funciona bien antes de crear
 * la interfaz gráfica.
 */

/*
 * Con esta anotación, le estamos indicando a Spring Boot que inicie la aplicación escaneando todos
 * los componentes en el paquete principal y sus subpaquetes. Spring se va a encargar de crear y
 * configurar todas las piezas de la aplicación (DataSourcer, DAOs, etc.). Para esto, tenemos que 
 * haber puesto la anotación de @Repository en los DAOs para que Spring detecte que son "beans"
 * (objetos gestionados por Spring)
 */
@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
public class TestRepositories {
    public static void main(String[] args) {
        // ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class);
        /*
         * El método run devuelve el contexto de la aplicación.
         * Arranca la aplicación Spring Boot completa, esto significa que:
         * 1- va a leer el application.properties
         * 2- configurar el DataSource con HikariCP
         * 3- Si está configurado el spring.sql.init.mode=always, ejecuta el schema_DDL.sql
         * y data_DML, limpiando y repoblando nuestra base de datos.
         * 4- crea instancias de nuestros DAOs y les inyecta el DataSource, esto es lo que se 
         * conoce como Inversión de Control o Inversión de Dependencias
         * 
         * El objeto de ConfigurableApplicationContext  es el Contenedor de Inversión de Control
         * (IoC) de Spring Boot.
         * Es el corazón de Spring Boot, es el responsable de escanear el código en búsqueda de 
         * anotaciones, cargar las configuraciones.
         */

         try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_AlumnoRepository alumnoDAO = context.getBean(AlumnoDAO.class);
            I_CursoRepository cursoDAO = context.getBean(CursoDAO.class);

            //Pruebas de alumnos

            // Test 1: Crear un alumno
            System.out.println("\n>>> Test 1: creando un alumno");
            Alumno nuevoAlumno = new Alumno(0, "Ricardo", "Iorio", 63, 1, true);
            alumnoDAO.create(nuevoAlumno);
            if(nuevoAlumno.getId()>0){
                System.out.println(" ## Alumno creado correctamente con el id " + nuevoAlumno.getId());
                System.out.println(nuevoAlumno);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear al alumno !!");
            }


         } catch (Exception e) {
            System.err.println("¡¡ ERROR EN LA BASE DE DATOS !!");
            e.printStackTrace();
         }

        

    }
}
