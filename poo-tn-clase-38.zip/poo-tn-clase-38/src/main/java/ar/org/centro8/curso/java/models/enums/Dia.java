package ar.org.centro8.curso.java.models.enums;

// enum es un tipo especial de clase en Java que define un conjunto fijo 
// de constantes con nombre. Se utiliza para representar valores limitados
// y conocidos de antemano.
public enum Dia {
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES;

    //un enum es como una lista de opciones fijas que impide poner cualquier
    //otro valor que no exista en esa lista.
    //cada valor dentro del enum son constantes que representan una instancia 
    //de la clase Enum, en este caso, son objetos de Dia que es un Enum.
    //Estos objetos pueden poseer atributos, para ello debe crearse un constructor
    // privado, que le permita asignar el valor como estado. Es privado, para
    //que desde afuera no se puedan crear más objetos del enum. 
    //Implementan Serializable y Comparable
    //No pueden extender de otra clase, pero pueden implentar interfaces
    //La interfaz Serializable en Java, marca una clase como capaz de convertirse
    //en una secuencia de bytes y luego reconstruirse a partir de esos bytes.
    
}
