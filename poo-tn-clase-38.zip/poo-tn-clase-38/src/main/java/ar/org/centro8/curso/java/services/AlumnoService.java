package ar.org.centro8.curso.java.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.curso.java.models.entities.Alumno;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_AlumnoRepository;

/**
 * Clase de servicio para la entidad Alumno
 * Encapsula toda la lógica de negocio relacionada con alumnos.
 * Actúa como un intermediario entre los controladores y los repositorios,
 * asegurando que los controladores sean "delgados" y que la lógica de negocio
 * sea reutilizable y probada en forma aislada.
 */
@Service
public class AlumnoService {
    private final I_AlumnoRepository alumnoRepository;

    public AlumnoService(I_AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    /**
     * Obtiene una lista de todos los alumnos.
     * Acá se podría añadir lógica de negocio adicional, antes o después de la llamada
     * al repositorio. Como validaciones de permisos, filtros complejos que no son
     * gestionados por el repositorio, etc.
     * @return  Una lista con todos los alumnos.
     * @throws SQLException Si ocurre un error al acceder a la base de datos.
     */
    public List<Alumno> obtenerTodosLosAlumnos() throws SQLException{
        return alumnoRepository.findAll();
        //la lógica actual solo delega al repositorio
        //En un caso real, acá podríamos tener las validaciones, como si el usuario tiene
        //permiso para ver a todos los alumnos. O transformaciones de datos, por ejemplo
        //ocultar ciertos campos.
    }

    /**
     * Guarda un nuevo alumno en la base o lo actualiza
     * @param alumno -> es el alumno a guardar o actulizar
     * @return -> es el objeto de Alumno (con el id generado si es nuevo)
     * @throws SQLException -> si hay un error al acceder a la BD
     * @throws IllegalArgumentException -> si la lógica de negocio detecta un error.
     */
    public Alumno guardarAlumno(Alumno alumno) throws SQLException{
        //ejemplo de lógica de negocio en la capa de servicio: validar antes de persistir
        if (alumno.getEdad()<18) {
            throw new IllegalArgumentException("La edad del alumno debe ser mayor o igual a 18 años.");
        }

        //si el alumno tiene un id, asumimos que es una actualización
        if(alumno.getId()!=0){
            alumnoRepository.update(alumno);
        } else {
            alumnoRepository.create(alumno);
        }
        return alumno;
    }

    /**
     * Busca un alumno por id
     * @param id -> es el id del alumno a buscar
     * @return -> el alumno si lo encontró o null si no lo encontró
     * @throws SQLException 
     */
    public Alumno buscarAlumnoPorId(int id) throws SQLException{
        return alumnoRepository.findById(id);
    }

    /**
     * Elimina un alumno por id
     * @param id -> id del alumno a eliminar
     * @return -> el número de filas afectadas (normalmente 1 si se eliminó y 0 si no se eliminó)
     * @throws SQLException
     */
    public int eliminarAlumno(int id) throws SQLException{
        //acá se podría agregar la lógica de verificar si el alumno tiene cursos asignados
        //antes de eliminar
        return alumnoRepository.delete(id);
    }

    /**
     * Busca alumnos por el id de un curso
     * @param idCurso -> id del curso por el que se va a filtrar
     * @return -> lista de alumnos asignados a ese curso (puede venir vacía)
     * @throws SQLException
     */
    public List<Alumno> buscarAlumnosPorCurso(int idCurso) throws SQLException{
        return alumnoRepository.findByCurso(idCurso);
    }

}
