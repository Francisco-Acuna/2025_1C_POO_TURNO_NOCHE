package ar.org.centro8.curso.java.models.entities;

import ar.org.centro8.curso.java.models.enums.Dia;
import ar.org.centro8.curso.java.models.enums.Turno;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Curso {
    private int id;
    private String titulo;
    private String profesor;
    private Dia dia;
    private Turno turno;
    private boolean activo;
}
