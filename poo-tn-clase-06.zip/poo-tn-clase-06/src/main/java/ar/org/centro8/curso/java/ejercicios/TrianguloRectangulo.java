package ar.org.centro8.curso.java.ejercicios;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class TrianguloRectangulo {

    //atributos
    private double base;
    private double altura;

    public double getPerimetro(){
        return base + altura + Math.hypot(base, altura);
    }

    public double getSuperficie(){
        return (base * altura) / 2;
    }

}
