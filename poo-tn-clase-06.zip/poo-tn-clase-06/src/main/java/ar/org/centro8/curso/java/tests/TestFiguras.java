package ar.org.centro8.curso.java.tests;

import java.text.DecimalFormat;

import ar.org.centro8.curso.java.ejercicios.Circulo;
import ar.org.centro8.curso.java.ejercicios.Rectangulo;
import ar.org.centro8.curso.java.ejercicios.TrianguloRectangulo;

public class TestFiguras {
    public static void main(String[] args) {
        DecimalFormat df = new DecimalFormat("0.00");

        //testeamos la clase Rectangulo
        Rectangulo rectangulo1 = new Rectangulo(12, 5);
        System.out.println(rectangulo1);
        System.out.println("El perímetro del rectángulo es:" + rectangulo1.getPerimetro());
        System.out.println("La superficie del rectángulo es: " + rectangulo1.getSuperficie());

        //testeamos la clase TrianguloRectangulo
        TrianguloRectangulo triangulo1 = new TrianguloRectangulo(15, 10);
        System.out.println(triangulo1);
        System.out.println("El perímetro del triángulo es: " + df.format(triangulo1.getPerimetro()));
        System.out.println("La superficie del triángulo es: " + triangulo1.getSuperficie());

        //testeamos la clase Circulo
        Circulo circulo1 = new Circulo(17);
        System.out.println(circulo1);
        System.out.println("El perímetro del círculo es: " + df.format(circulo1.getPerimetro()));
        System.out.println("La superficie del círculo es: " + df.format(circulo1.getSuperficie()));

    }
}
