package ar.org.curso.centro8.java.tests;

import java.util.ArrayList;
import java.util.List;
import ar.org.curso.centro8.java.entidades.Auto;

public class TestCollection {
    public static void main(String[] args) {
        //List
        /*
         * La interfaz List representa una lista con índices que emula a un vector.
         * List es la única que tiene métodos definidos con índices.
         * ArayList es una lista del tipo vector o Array que se diferencia por no ser 
         * estática, en este caso, la lista es dinámica.
         * LinkedList tiene el comportamiento heredado de List, internamente utiliza
         * una lista enlazada.
         * La clase Vector implementa List, pero no son los vectores que hemos estudiado
         * anteriormente. Es una colección que internamente utiliza la tecnología de
         * vectores. No se recomienda su uso en la actualidad, por ser una tecnología
         * en desuso, con código antiguo y poco performante, tiene una sincronización que
         * la vuelve muy lenta.
         * ArrayList es una lista tipo vector o Array, LinkedList es una lista enlazada.
         * Diferencia:
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos.
         */

        List lista;

        lista = new ArrayList();

        //el método .add() me permite agregar elementos.
        lista.add(new Auto("Peugeot", "308", "Negro"));
        lista.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        lista.add("hola");
        lista.add(83);
        lista.add(23.45);

        //recorrido de una lista
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i)); //el método get obtiene el elemento de la lista
        }
        //el método size() devuelve la longitud de la lista

        //el método remove() elimina un elemento de la lista
        lista.remove(3);

        //recorrido con for-each
        for(Object elemento:lista) System.out.println(elemento);

        //Iterable
        /*
         * Iterable es el padre de todas las interfaces en el framework Collections.
         * Dentro de Iterable se encuentra definido el método default foreach.
         * Este método realiza un recorrido. La idea es que no tengamos nosotros que 
         * realizar una estructura de repetición, si no que sea la misma lista la
         * que se autorrecorra. Es una forma de escribir código más moderna y aparece 
         * a partir del JDK 8.
        */

        System.out.println("\nRecorrido foreach()");
        lista.forEach(item->System.out.println(item));
        /*
         el método foreach() recibe un objeto del tipo Consumer que define qué operación
         se ejecutará sobre cada elemento de la colección.
         Consumer es una interdaz funcional cuyo propósito es "consumir" un valor.
         Representa una operación que recibe un argumento del tipo "T" y no devuelve nada.
         T es un tipo de dato genérico.
         Generalmente se implementa una expresión Lambda (Lambda Expression)
         Las Lambdas Expression son funciones anónimas que aparecen a partir del JDK 8.
         Una función anónima es una porción de código (una función) que no tiene nombre
         y se define en el sitio donde se va a usar.
         Se utiliza para simplificar código.
         
        */

    }
}
