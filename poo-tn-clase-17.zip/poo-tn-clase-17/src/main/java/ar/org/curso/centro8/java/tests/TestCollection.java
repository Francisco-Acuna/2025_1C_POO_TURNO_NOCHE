package ar.org.curso.centro8.java.tests;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import ar.org.curso.centro8.java.entidades.Auto;

public class TestCollection {
    public static void main(String[] args) {
        //List
        /*
         * La interfaz List representa una lista con índices que emula a un vector.
         * List es la única que tiene métodos definidos con índices.
         * ArayList es una lista del tipo vector o Array que se diferencia por no ser 
         * estática, en este caso, la lista es dinámica.
         * LinkedList tiene el comportamiento heredado de List, internamente utiliza
         * una lista enlazada.
         * La clase Vector implementa List, pero no son los vectores que hemos estudiado
         * anteriormente. Es una colección que internamente utiliza la tecnología de
         * vectores. No se recomienda su uso en la actualidad, por ser una tecnología
         * en desuso, con código antiguo y poco performante, tiene una sincronización que
         * la vuelve muy lenta.
         * ArrayList es una lista tipo vector o Array, LinkedList es una lista enlazada.
         * Diferencia:
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos.
         */

        List lista;

        lista = new ArrayList();

        //el método .add() me permite agregar elementos.
        lista.add(new Auto("Peugeot", "308", "Negro"));
        lista.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        lista.add("hola");
        lista.add(83);
        lista.add(23.45);

        //recorrido de una lista
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i)); //el método get obtiene el elemento de la lista
        }
        //el método size() devuelve la longitud de la lista

        //el método remove() elimina un elemento de la lista
        lista.remove(3);

        //recorrido con for-each
        for(Object elemento:lista) System.out.println(elemento);

        //Iterable
        /*
         * Iterable es el padre de todas las interfaces en el framework Collections.
         * Dentro de Iterable se encuentra definido el método default foreach.
         * Este método realiza un recorrido. La idea es que no tengamos nosotros que 
         * realizar una estructura de repetición, si no que sea la misma lista la
         * que se autorrecorra. Es una forma de escribir código más moderna y aparece 
         * a partir del JDK 8.
        */

        System.out.println("\nRecorrido foreach()");
        lista.forEach(item->System.out.println(item));
        /*
         el método foreach() recibe un objeto del tipo Consumer que define qué operación
         se ejecutará sobre cada elemento de la colección.
         Consumer es una interfaz funcional cuyo propósito es "consumir" un valor.
         Representa una operación que recibe un argumento del tipo "T" y no devuelve nada.
         T es un tipo de dato genérico.
         Generalmente se implementa una expresión Lambda (Lambda Expression)
         Las Lambdas Expression son funciones anónimas que aparecen a partir del JDK 8.
         Una función anónima es una porción de código (una función) que no tiene nombre
         y se define en el sitio donde se va a usar.
         Se utiliza para simplificar código.         
        */

        //si quisiéramos utilizar más de una sentencia en el bloque, tenemos que abrir llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("-");
        });

        //Method Refences (referencia de métodos)
        System.out.println("\nRecorrido con foreach simplificado");
        //si vamos a escirbir una única sentencia, podemos omitir el uso del iterador
        lista.forEach(System.out::println);
        //con el operador 4 puntos :: le estamos indicando a Java que el ítem implícito
        //lo coloque como argumento del método

        System.out.println("\n** ListIterator **\n");
        /*
         * ListIterator es una interfaz especializada para recorrer colecciones que implementan
         * List. A diferencia del Iterator, o del método forEach simple de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         * - Recorrido bidireccional: permite avanzar y retroceder sobre las listas
         * - Tiene acceso a índices
         * - Permite eliminar, reemplazar y agregar elementos durante la iteración
         */

         List nombres = new ArrayList();

         nombres.add("Ricardo");
         nombres.add("Jenny");
         nombres.add("Carlos");
         nombres.add("Ana");
         nombres.add("Marcela");

         //Obtenemos el ListIterator de la la lista nombres
         ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\n**Recorrido hacia adelante**");
        while(li.hasNext()) { //hasNext() devuelve un booleano que indica si hay un siguiente elemento
            int indice = li.nextIndex(); //devuelve el siguiente índice
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice: " + indice + " : " + nombre);
        }

        //recorrido hacia atrás
        System.out.println("\n**Recorrido hacia atrás**");
        while(li.hasPrevious()){
            int indice = li.previousIndex(); // índice anterior
            String nombre = li.previous(); //elemento anterior
            System.out.println("Índice:" + indice + " : " + nombre);
        }

        //reemplazar elementos
        System.out.println("\n**Reemplazar elementos**");
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Carlos")) li.set("David"); //reemplaza Carlos por David
        }

        System.out.println("Lista de nombres después de reemplazar a Carlos por David: " + nombres);

        //agregar elementos
        System.out.println("\n**Agregar elementos**");
        //reiniciar la posición del cursor
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Ana")) li.add("Juan");
        }

        System.out.println("Lista de nombres después de agregar a Juan luego de Ana: " + nombres);

        //eliminar elementos
        System.out.println("\n**Eliminar elementos**");
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Jenny")) li.remove(); //elimina el elemento actual ("Jenny")
        }

        System.out.println("Lista de nombres después de eliminar a Jenny: " + nombres);
        System.out.println();

        //========================
        //      Generics
        //========================
        /*Para especificar el tipo de datos de una lista, lo hacemos a través de los Generics
        Los Generics aparecieron en Java a partir del JDK 5 y son una característica que
        permite crear clases, interfaces o métodos con tipos de datos parametrizados.        
        */

        List<Auto> lista2 = new ArrayList<>();
        //No pueden crearse colecciones de tipos de datos primitivos, en su lugar se deben 
        //utilizar los wrappers, por ej. int -> Integer, double -> Double, char -> Character

        lista2.add(new Auto("Renault", "Clio", "Rojo"));
        // lista2.add("Hola"); //error no puedo agregar cualquier elemento

        Auto auto1 = (Auto) lista.get(0);
        Auto auto2 = lista2.get(0);

        //Vamos a copiar los autos de la lista a lista2
        lista.forEach(item -> {
            if(item instanceof Auto){
                lista2.add((Auto) item);
            }
        });

        //recorremos la lista2
        System.out.println("\n**Recorrido de lista2:");
        lista2.forEach(System.out::println);




    }
}
