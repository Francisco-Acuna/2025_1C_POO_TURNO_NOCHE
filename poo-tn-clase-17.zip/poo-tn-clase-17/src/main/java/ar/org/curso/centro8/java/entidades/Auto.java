package ar.org.curso.centro8.java.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
public class Auto {
    private String marca;
    private String modelo;
    private String color;
}
