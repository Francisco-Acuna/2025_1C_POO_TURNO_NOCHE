package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.enums.PruebaEnum;

public class TestPruebaEnumerados {
    public static void main(String[] args) {
        System.out.println(PruebaEnum.EN_PROGRESO);
    }
}
