package ar.org.centro8.curso.java.tests;

import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.AlumnoDAO;
import ar.org.centro8.curso.java.repositories.CursoDAO;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;

/*
 * Esta clase utilizará el contexto de Spring Boot para obtener los DAOs y ejecutar operaciones.
 * Esta clase no es parte de la lógica de negocio de la aplicación en sí, sino una herramienta
 * para probar manualmente que nuestras capas de entidades y accesos a datos, funcionen correctamente.
 * Es como un banco de pruebas.
 * Necesitamos realizar las pruebas para asegurarnos de que todo funciona bien antes de crear
 * la interfaz gráfica.
 */

/*
 * Con esta anotación, le estamos indicando a Spring Boot que inicie la aplicación escaneando todos
 * los componentes en el paquete principal y sus subpaquetes. Spring se va a encargar de crear y
 * configurar todas las piezas de la aplicación (DataSourcer, DAOs, etc.). Para esto, tenemos que 
 * haber puesto la anotación de @Repository en los DAOs para que Spring detecte que son "beans"
 * (objetos gestionados por Spring)
 */
@SpringBootApplication(scanBasePackages = "ar.org.centro8.curso.java")
public class TestRepositories {
    public static void main(String[] args) {
        // ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class);
        /*
         * El método run devuelve el contexto de la aplicación.
         * Arranca la aplicación Spring Boot completa, esto significa que:
         * 1- va a leer el application.properties
         * 2- configurar el DataSource con HikariCP
         * 3- Si está configurado el spring.sql.init.mode=always, ejecuta el schema_DDL.sql
         * y data_DML, limpiando y repoblando nuestra base de datos.
         * 4- crea instancias de nuestros DAOs y les inyecta el DataSource, esto es lo que se 
         * conoce como Inversión de Control o Inversión de Dependencias
         * 
         * El objeto de ConfigurableApplicationContext  es el Contenedor de Inversión de Control
         * (IoC) de Spring Boot.
         * Es el corazón de Spring Boot, es el responsable de escanear el código en búsqueda de 
         * anotaciones, cargar las configuraciones.
         */

         try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class,args);) {
            I_AlumnoRepository alumnoDAO = context.getBean(AlumnoDAO.class);
            I_CursoRepository cursoDAO = context.getBean(CursoDAO.class);

            //Pruebas de alumnos

            // Test 1: Crear un alumno
            System.out.println("\n>>> Test 1: creando un alumno");
            Alumno nuevoAlumno = new Alumno(0, "Ricardo", "Iorio", 63, 1, true);
            alumnoDAO.create(nuevoAlumno);
            if(nuevoAlumno.getId()>0){
                System.out.println(" ## Alumno creado correctamente con el id " + nuevoAlumno.getId());
                System.out.println(nuevoAlumno);
            }else {
                System.err.println(" ¡¡ ERROR - no se pudo crear al alumno !!");
            }

            //TEST 2: Buscar un Alumno por ID (existente)
            System.out.println("\n>>> Test 2: Buscando alumno por ID " + nuevoAlumno.getId() + "...");
            Alumno alumnoEncontrado = alumnoDAO.findById(nuevoAlumno.getId());
            if(alumnoEncontrado!=null){
                System.out.println(" ## Alumno encontrado: " + alumnoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró el alumno con el ID " + nuevoAlumno.getId());
            }

            //TEST 3: Buscar un Alumno por ID (inexistente)
            System.out.println("\n>>> Test 3: Buscando Alumno con ID 999 (inexistente)");
            Alumno alumnoNoEncontrado = alumnoDAO.findById(999);
            if(alumnoNoEncontrado != null){
                System.out.println(" ## Alumno encontrado: " + alumnoNoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontró alumno con ID 999 !!");
            }

            //Test 4: Actualizar un Alumno
            System.out.println("\n>>> Test 4: Actualizando Alumno " + nuevoAlumno.getId() + "...");
            nuevoAlumno.setNombre("Ricardo Horacio"); //cambia el nombre del alumno recién creado
            int filasAfectadas = alumnoDAO.update(nuevoAlumno);
            if(filasAfectadas==1){
                System.out.println(" ## Alumno " + nuevoAlumno.getId() + "actualizado correctamente");
                System.out.println(" ## Verificando actualización: " + alumnoDAO.findById(nuevoAlumno.getId()));
            } else {
                System.err.println(" ¡¡ ERROR -  No se pudo actualizar al alumno !!");
            }
            
            //Test 5: Listar todos los alumnos
            System.out.println("\n>>> Test 5: Listando todos los alumnos...");
            List<Alumno> alumnosTodos = alumnoDAO.findAll();
            if(!alumnosTodos.isEmpty()){
                System.out.println(" ## Alumnos encontrados: " + alumnosTodos.size());
                alumnosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontraron alumnos");
            }

            //Test 6: Eliminar un alumno
            System.out.println("\n>>> Test 6: Eliminando Alumno " + nuevoAlumno.getId() + "...");
            int filasAfectadasDelete = alumnoDAO.delete(nuevoAlumno.getId());
            if(filasAfectadasDelete==1){
                System.out.println(" ## Alumno " + nuevoAlumno.getId() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + alumnoDAO.findById(nuevoAlumno.getId()));
            } else {
                System.err.println(" ¡¡ ERROR - No se pudo eliminar al alumno !!");
            }

            //Pruebas para cursos
            
            //Test 7: Crear un nuevo Curso
            System.out.println("\n>>> Test 7: creando un nuevo Curso...");
            Curso nuevoCurso = new Curso(0, "Programación Java Avanzada", "Francisco El Magnífico",
                                            Dia.LUNES, Turno.NOCHE, true);
            cursoDAO.create(nuevoCurso);
            if(nuevoCurso.getId()>0){
                System.out.println(" ## Curso creado correctamente con id " + nuevoCurso.getId());
                System.out.println(nuevoCurso);
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo crear el curso !!");
            }

            //Test 8: Buscar un Curso por ID 
            System.out.println("\n>>> Test 8: buscando curso por ID " + nuevoCurso.getId() + " ...");
            Curso cursoEncontrado = cursoDAO.findById(nuevoCurso.getId());
            if(cursoEncontrado!=null){
                System.out.println(" ## Curso encontrado: " + cursoEncontrado);
            } else {
                System.err.println(" ¡¡ ERROR - no se encontró el curso con ID " + nuevoCurso.getId());
            }

            //Test 9: Listar todos los cursos
            System.out.println("\n>>> Test 9: listar todos los cursos");
            List<Curso> cursosTodos = cursoDAO.findAll();
            if(!cursosTodos.isEmpty()){
                System.out.println(" ## Cursos encontrados: " + cursosTodos.size());
                cursosTodos.forEach(System.out::println);
            } else {
                System.err.println(" ¡¡ ERROR - No se encontraron cursos !!");
            }

            //Test 10: Buscar cursos por Día y Turno
            System.out.println("\n>>> Test 10: buscando cursos de LUNES por la MAÑANA");
            List<Curso> cursosLunesManiana = cursoDAO.findByDiaAndTurno(Dia.LUNES, Turno.MAÑANA);
            if(!cursosLunesManiana.isEmpty()){
                System.out.println(" ## Cursos encontrados (LUNES, MAÑANA): " + cursosLunesManiana.size());
                cursosLunesManiana.forEach(System.out::println);
            } else{
                System.out.println(" ¡¡ No se encontraron cursos para LUNES por la MAÑANA");
                //no necesariamente es un error que no haya cursos
            }

            //Test 11: Actualizar un curso
            System.out.println("\n>>> Test 11: Actualizando Curso " + nuevoCurso.getId() + " ...");
            nuevoCurso.setProfesor("Rob Halford");
            nuevoCurso.setActivo(false);
            int filasAfectadasCurso = cursoDAO.update(nuevoCurso);
            if(filasAfectadasCurso==1){
                System.out.println(" ## Curso " + nuevoCurso.getId() + " actualizado correctamente.");
                System.out.println("Verificando actualización: " + cursoDAO.findById(nuevoCurso.getId()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo actualizar el curso !!");
            }

            //Test 12: Eliminar un curso
            System.out.println("\n>>> Test 12: eliminando el curso " + nuevoCurso.getId());
            int filasAfectadasCursosDelete = cursoDAO.delete(nuevoCurso.getId());
            if(filasAfectadasCursosDelete == 1){
                System.out.println(" ## Curso " + nuevoCurso.getId() + " eliminado correctamente");
                System.out.println("Verificando eliminación: " + cursoDAO.findById(nuevoCurso.getId()));
            } else {
                System.err.println(" ¡¡ ERROR - no se pudo eliminar el curso !!");
            }

         } catch (Exception e) {
            System.err.println("¡¡ ERROR EN LA BASE DE DATOS !!");
            e.printStackTrace();
         } finally {
            System.out.println("<<< Pruebas finalizadas >>>");
            System.out.println("<<< Contexto de Spring cerrado >>>");
         }

        

    }
}
