package ar.org.centro8.curso.java.repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

@Repository
public class AlumnoDAO implements I_AlumnoRepository{
    //creamos un objeto de DataSource que nos permita obtener la conexión a la base de datos
    //tomando una conexión del pool de conexiones que gestiona con HikariCP
    private final DataSource dataSource;

    //definimos una serie de atributos estáticos (para ahorrar memoria) y constantes (para
    //garantizar que no se cambie la consulta en tiempo de ejecución)
    //representan consultas SQL
    //las agrupamos al principio para tener una mayor claridad en el código y facilitar el
    //mantenimiento. 

    private static final String SQL_CREATE = 
        "INSERT INTO alumnos (nombre, apellido, edad, idCurso, activo) values (?,?,?,?,?)";
        //los signos de interrogación son marcadores de posición para los valores que
        //se establecerán más adelante
    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM alumnos WHERE id=?";
    private static final String SQL_FIND_ALL = 
        "SELECT * FROM alumnos";
    private static final String SQL_UPDATE =
        "UPDATE alumnos SET nombre=?, apellido=?, edad=?, idCurso=?, activo=? WHERE id=?";
    private static final String SQL_DELETE = 
        "DELETE FROM alumnos WHERE id=?";
    private static final String SQL_FIND_BY_CURSO = 
        "SELECT * FROM alumnos WHERE idCurso=?";
    
    //el constructor de la clase recibe como parámetro un objeto de DataSource
    public AlumnoDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    //de esta manera, el repositorio queda configurado con la fuente de conexiones que usará
    //siempre. El repositorio no crea su propio DataSource, si no que se le proporciona uno
    //configurado con HikariCP. Mantenemos un diseño limpio y testeable, ya que se pueden crear
    //varias instancias con distintos DataSource.

    @Override
    public void create(Alumno alumno) throws SQLException {
        try (Connection conn = dataSource.getConnection(); //obtenemos la conexión
                PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)){
                //PreparedStatement es una interfaz de Java (JDBC) que representa una plantilla de
                //consulta o comando SQL. Sirve para ejecutar consultas SQL de forma segura y eficiente,
                //especialmente cuando estas consultas usan valores variables. Llamamos al método
                //preparedStatement de la conexión, primero le pasamos la constante que contiene la
                //sentencia SQL.
                //Statement.RETURN_GENERATED_KEYS le indica a la base de datos que, después de ejecutar
                //el INSERT, debe devolver las claves generadas automáticamente, por lo general es el 
                //id autoincremental de la nueva fila de la base de datos.
            ps.setString(1, alumno.getNombre());        
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.setBoolean(5, alumno.isActivo());
            ps.executeUpdate(); // ejecuta la sentencia SQL. Para las sentencias que modifican datos
            //(INSERT, UPDATE, DELETE) se utiliza executeUpdate()
            try (ResultSet keys = ps.getGeneratedKeys()) {
                //recupera las claves autogeneradas (el id del nuevo registro)
                //ResultSet es una interfaz de Java (JDBC) que representa un conjunto de resultados
                //de una consulta SQL. Como convención, se utiliza la palabra keys como nombre de            }
                //variable porque contiene las llaves (claves) generadas.
                //getGeneratedKeys() es el método que se utiliza para recuperar el ResultSet que contiene
                //cualquier clave autogeneradas por la base de datos.
                if(keys.next()){
                    //next() mueve el curso hacia la siguiente fila (o la primera si arranca ahí)
                    //es esencial llamar a next() antes de intentar leer cualquier dato de un ResultSet
                    alumno.setId(keys.getInt(1));
                    //getInt() recupera el valor entero de la primera columna del ResultSet de claves generadas
                    //asumimos que la primera columna contiene el id autoincremental.
                    //alumnos.setId() establecemos el ID generado en el objeto alumno que se pasó
                    //al método. 
                }
            }
        }
    }

    @Override
    public Alumno findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { //ejecuta la consulta SQL (SELECT)
                //para consultas que devuelven datos, se utiliza executeQuery(), que retorna
                //un ResultSet con los resultados de la consulta.
                if(rs.next()){
                    return mapRow(rs);
                }                
            }
        } 
        return null;
    }

    @Override
    public List<Alumno> findAll() throws SQLException {
        List<Alumno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
                ResultSet rs = ps.executeQuery()){
            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        } 
        return lista;
    }

    @Override
    public int update(Alumno alumno) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.setBoolean(5, alumno.isActivo());
            ps.setInt(6, alumno.getId());
            int filasAfectadas = ps.executeUpdate(); //almacena el resultado de la ejecución
            return filasAfectadas; //devuelve el número de filas afectadas
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {
            ps.setInt(1, id);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas;
        } 
    }

    @Override
    public List<Alumno> findByCurso(int idCurso) throws SQLException {
        List<Alumno> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
                PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_CURSO)) {
            ps.setInt(1, idCurso);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            } 
        } 
        return lista;
    }


    //creamos un método que centraliza la lógica de mapeo del ResultSet a objeto en Java
    //evitando la duplicación de código y haciendo el código más limpio.
    private Alumno mapRow(ResultSet rs) throws SQLException{
        Alumno alumno = new Alumno();
        alumno.setId(rs.getInt("id"));
        alumno.setNombre(rs.getString("nombre"));
        alumno.setApellido(rs.getString("apellido"));
        alumno.setEdad(rs.getInt("edad"));
        alumno.setIdCurso(rs.getInt("idCurso"));
        alumno.setActivo(rs.getBoolean("activo"));
        return alumno;
    }
     
    

}
