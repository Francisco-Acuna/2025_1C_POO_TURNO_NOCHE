package ar.org.curso.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTnClase21Application {

	public static void main(String[] args) {
		SpringApplication.run(PooTnClase21Application.class, args);
	}

}
