package ar.org.curso.centro8.java.tests;

import java.util.ArrayList;
import java.util.List;

import ar.org.curso.centro8.java.entidades.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        //API Stream (JDK 8)
        /*
         * Permite procesar flujos de datos de manera uniforme, independientemente de la fuente
         * (archivos, BD, web service, etc.), usando un enfoque declarativo con expresiones
         * Lambdas.
         * API (Application Programming Interface): Conjunto de métodos e interfaces que 
         * facilitan el acceso a funcionalidades sin conocer su implementación interna.
         */

        List<Persona> personas = new ArrayList<>();
        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 41));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Estela", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Monica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //select * from personas;
        personas.forEach(System.out::println);

        //Stream provee métodos para filtrar
        //el método stream() devuelve una implementación de la interface Stream
        //el método filter() permite sobreescribir un predicado de expresión Lambda
        //(un predicado es una interface funcional que define una condición que un objeto
        //determinado, debe cumplir)

        //select * from personas where nombre = "Ana";
        System.out.println("\nselect * from personas where nombre = \"Ana\";");
        personas
                .stream() //devuelve una secuencia de elementos para procesarlos (no guarda los elementos)
                .filter(p->p.getNombre().equals("Ana")) //obtenemos un objeto del tipo Persona, luego va la
                //expresión booleana, si arroja true, es parte de los resultados, si arroja false, no es parte
                //de los resultados
                .forEach(System.out::println); //filter devuelve un stream con todos los registros

        
        System.out.println("\nselect * from personas where nombre=\"Ana\" or nombre=\"Juan\"");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like 'ja%'");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("ja"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like \'%a\'");
        personas    
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);
        

    }
}
