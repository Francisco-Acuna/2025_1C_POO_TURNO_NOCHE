package ar.org.centro8.curso.java.enums;


public enum PruebaEnum {
    PENDIENTE("Pendiente de entrega"),
    EN_PROGRESO("En proceso de entrega"),
    ENTREGADO("Entrega realizada");

    private String descripcion;

    private PruebaEnum(String descripcion){
        this.descripcion=descripcion;
    }

    @Override
    public String toString(){
        return descripcion;
    }
}
