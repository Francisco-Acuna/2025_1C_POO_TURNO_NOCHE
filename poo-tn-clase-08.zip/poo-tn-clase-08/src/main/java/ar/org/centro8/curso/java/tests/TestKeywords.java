package ar.org.centro8.curso.java.tests;

public class TestKeywords {
    public static void main(String[] args) {
        
    }
}
