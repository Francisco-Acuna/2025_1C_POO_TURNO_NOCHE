package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class EmpleadoComposicion {
    //Las relaciones de composición son de las más fuertes.
    //Una clase, no tiene sentido sin el objeto de la otra clase que lo compone.
    //Las reconocemos con las palabras "siempre tiene un/a".
    //Por ejemplo en este caso, un empleado siempre tiene un auto.

    private int legajo;
    private String nombre;
    private String apellido;
    @NonNull
    private Auto auto;

    //un ejemplo de composición más fuerte 
    public EmpleadoComposicion(int legajo, String nombre, String apellido, String marca, String modelo, String color) {
        this.legajo = legajo;
        this.nombre = nombre;
        this.apellido = apellido;
        this.auto = new Auto(marca, modelo, color);
    }

    //no podemos crear un empleado sin que tenga un auto.

    
}
