package ar.org.centro8.curso.java.entidades.keywords;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class Automovil {
    private final String marca;
    private final String modelo;
    private final String color;
    private static int velocidad;


    /*
     * final
     * cuando una variable o atributo es declarado final, queda constante. No se puede 
     * modificar su valor. La keyword (palabra reservada) final a nivel atributo o
     * variable determina que la misma es una constante.
     * A nivel clase, la keyword final, indica que esa clase no puede tener clases hijas.
     */

    /*
     * static
     * Un atributo estático, pertenece a la clase, no a los objetos.
     * Su estado es compartido por todas las instancias de la clase. 
     * Se accede al miembro estático directamente a través del nombre de la clase.
     */

    public Automovil(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

}
