package ar.org.centro8.curso.java.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import ar.org.centro8.curso.java.models.entities.Curso;
import ar.org.centro8.curso.java.models.enums.Dia;
import ar.org.centro8.curso.java.models.enums.Turno;
import ar.org.centro8.curso.java.models.repositories.interfaces.I_CursoRepository;

/**
 * Clase de servicio para la entidad Curso
 * Encapsula la lógica de negocio relacionada con los cursos
 */
@Service
public class CursoService {
    private final I_CursoRepository cursoRepository;

    public CursoService(I_CursoRepository cursoRepository) {
        this.cursoRepository = cursoRepository;
    }

    public List<Curso> obtenerTodosLosCursos() throws SQLException{
        return cursoRepository.findAll();
    }

    public Curso guardarCurso(Curso curso) throws SQLException{
        //Ejemplo de lógica de negocio: asegurar de que un nuevo curso sea activo por defecto
        if(curso.getId()==0){ //si es un curso nuevo
            curso.setActivo(true); //se establece como activo
        }
        //se podrían agregar validaciones, como que el título no esté duplicado, etc.
        if(curso.getId()!=0){
            cursoRepository.update(curso);
        } else {
            cursoRepository.create(curso);
        }
        return curso;
    }

    public Curso buscarCursoPorId(int id) throws SQLException{
        return cursoRepository.findById(id);
    }

    public int eliminarCurso(int id) throws SQLException{
        return cursoRepository.delete(id);
        //se podría agregar la lógica de chequear que no haya alumnos inscriptos en este curso
    }

    public List<Curso> buscarCursoPorDiaYTurno(Dia dia, Turno turno) throws SQLException{
        return cursoRepository.findByDiaAndTurno(dia, turno);
    }

}
