package ar.org.centro8.curso.java.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import ar.org.centro8.curso.java.services.AlumnoService;
import ar.org.centro8.curso.java.services.CursoService;

@Controller
public class AlumnoController {
    //inyectamos los servicios, no los repositorios directamente
    //El controlador delega la lógica de negocio a los servicios
    private final AlumnoService alumnoService;
    private final CursoService cursoService;

    //constructor para la inyección de dependencias
    //Spring inyectará automáticamente las instancias de AlumnoService y CursoService
    public AlumnoController(AlumnoService alumnoService, CursoService cursoService) {
        this.alumnoService = alumnoService;
        this.cursoService = cursoService;
    }

    //método para mostrar la lista de alumnos
    @GetMapping("/") //anotación de Spring MVC que indica que el método se ejecutará cuando
    //el navegador haga una petición GET a la raíz del sitio.
    //una petición GET es cuando el navegador pide una página o recurso
    //La raíz (/) es la dirección base del sitio, sin ninguna ruta adicional
    //Cuando utilizamos GetMapping le estamos diciendo a Spring que cuando el usuario entre
    //en la página principal, se ejecute este método
    //El método se llama home() porque nos lleva a la home de la aplicación, pero podría llevar
    //cualquier otro nombre como "inicio". "bienvenida", "principal", etc.
    //Para este proyecto, utilizaremos la vista de los alumnos como home para mostrar el 
    //funcionamiento completo del MVC con JDBC
    public String home(Model model){
        
    }




}
