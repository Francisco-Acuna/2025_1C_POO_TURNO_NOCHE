package ar.org.centro8.curso.java.models.enums;

public enum Turno {
    MAÑANA, TARDE, NOCHE;
}
