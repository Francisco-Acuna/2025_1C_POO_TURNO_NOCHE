-- Inserción de 10 registros para la tabla 'cursos'
INSERT INTO cursos (titulo, profesor, dia, turno) VALUES
('Matemáticas Avanzadas', 'Carlos Pérez', 'LUNES', 'NOCHE'),
('Historia Contemporánea', 'Ana García', 'MARTES', 'TARDE'),
('Programación Web', 'Luis Rodríguez', 'MIERCOLES', 'NOCHE'),
('Literatura Universal', 'Sofía Fernández', 'JUEVES', 'MAÑANA'),
('Física Cuántica', 'Javier López', 'VIERNES', 'TARDE'),
('Diseño Gráfico', 'Marta Martínez', 'LUNES', 'MAÑANA'),
('Química Orgánica', 'Pedro Sánchez', 'MARTES', 'NOCHE'),
('Economía Global', 'Elena Díaz', 'MIERCOLES', 'TARDE'),
('Filosofía Antigua', 'Diego Ruiz', 'JUEVES', 'NOCHE'),
('Inglés Avanzado', 'Laura Smith', 'VIERNES', 'MAÑANA');

-- Inserción de 30 registros para la tabla 'alumnos'
-- Los idCurso se asignan de forma que referencien los IDs generados en la tabla 'cursos'.
-- Asumiendo que los IDs de cursos van del 1 al 10.
INSERT INTO alumnos (nombre, apellido, edad, idCurso) VALUES
('Ana', 'Gómez', 20, 1),
('Juan', 'Pérez', 22, 1),
('María', 'Rodríguez', 21, 2),
('Carlos', 'Sánchez', 23, 2),
('Laura', 'Martínez', 19, 3),
('Pedro', 'Díaz', 20, 3),
('Sofía', 'Fernández', 22, 4),
('Miguel', 'López', 24, 4),
('Elena', 'Ruiz', 21, 5),
('David', 'Torres', 20, 5),
('Isabel', 'Vargas', 19, 6),
('Francisco', 'Castro', 22, 6),
('Gabriela', 'Herrera', 20, 7),
('José', 'Morales', 23, 7),
('Valeria', 'Jiménez', 21, 8),
('Ricardo', 'Navarro', 20, 8),
('Camila', 'Silva', 19, 9),
('Andrés', 'Rojas', 22, 9),
('Daniela', 'Flores', 20, 10),
('Pablo', 'Acosta', 23, 10),
('Lucía', 'Benítez', 21, 1),
('Fernando', 'González', 20, 2),
('Carolina', 'Ramírez', 19, 3),
('Sergio', 'Ortiz', 22, 4),
('Mariana', 'Núñez', 20, 5),
('Esteban', 'Blanco', 23, 6),
('Paula', 'Méndez', 21, 7),
('Jorge', 'Guerrero', 20, 8),
('Natalia', 'Reyes', 19, 9),
('Alejandro', 'Cruz', 22, 10);

