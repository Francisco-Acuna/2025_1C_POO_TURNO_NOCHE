-- CREATE DATABASE IF NOT EXISTS colegio_noche;
-- USE colegio_noche;

DROP TABLE IF EXISTS alumnos;
DROP TABLE IF EXISTS cursos;

CREATE TABLE cursos(
    id int auto_increment primary key,
    titulo varchar(100) not null check(length(titulo) >=3),
    profesor varchar(100) not null check(length(profesor) >=3),
    dia enum('LUNES', 'MARTES', 'MIERCOLES', 'JUEVES', 'VIERNES') not null,
    turno enum('MAÑANA', 'TARDE', 'NOCHE') not null,
    activo boolean default true
);

CREATE TABLE alumnos(
    id int auto_increment primary key,
    nombre varchar(100) not null check(length(nombre)>=3),
    apellido varchar(100) not null check(length(apellido)>=3),
    edad int not null,
    idCurso int not null,
    activo boolean default true
);

ALTER TABLE alumnos add constraint FK_alumnos_idCurso
foreign key (idCurso) references cursos(id);

