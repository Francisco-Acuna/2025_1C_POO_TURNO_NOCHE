package ar.org.centro8.curso.java.repositories;

import javax.sql.DataSource;

import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

public class AlumnoDAO implements I_AlumnoRepository{
    //creamos un objeto de DataSource que nos permita obtener la conexión a la base de datos
    //tomando una conexión del pool de conexiones que gestiona con HikariCP
    private final DataSource dataSource;

    //definimos una serie de atributos estáticos (para ahorrar memoria) y constantes (para
    //garantizar que no se cambie la consulta en tiempo de ejecución)
    

}
