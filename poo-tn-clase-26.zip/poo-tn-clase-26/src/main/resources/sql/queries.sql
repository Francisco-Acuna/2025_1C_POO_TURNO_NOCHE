use colegio_noche;
-- 1. listar todos los alumnos junto con el título de su curso
select  a.*, 
        c.titulo 
from    alumnos a 
join    cursos c 
on      a.idCurso=c.id; 

-- 2. obtener la cantidad de alumnos por curso
select      c.id,
            c.titulo,
            count(a.id) cantidad_alumnos
from        cursos c
left join   alumnos a
on          c.id=a.idCurso
group by    c.id;

-- 3. mostrar alumnos activos y sus respectivos profesores
select      a.id,
            a.nombre,
            a.apellido,
            c.profesor
from        alumnos a
join        cursos c
on          a.idCurso=c.id
where       a.activo;

-- 4. listar títulos de cursos que tienen alumnos mayores de 15 años
select      distinct c.titulo
from        cursos c
join        alumnos a
on          c.id=a.idCurso
where       a.edad > 15;
