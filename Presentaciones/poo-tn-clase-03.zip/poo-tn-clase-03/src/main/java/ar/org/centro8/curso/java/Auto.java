package ar.org.centro8.curso.java;

public class Auto {
    //Una clase es una plantilla o molde que define los atributos y 
    //métodos que tendrán los objetos.

    //atributos
    //definimos los atributos o propiedades que son las variables
    //que representan las características
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores
    //si no definimos un constructor, se crea uno vacío por defecto
    Auto(){}; //constructor vacío

    //sobrecarga de constructores
    //constructor completo
    Auto(String marca, String modelo, String color, int velocidad){
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = velocidad;
    }

    //más sobrecarga de constructores (sin la velocidad)
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    //más sobrecarga sin marca ni velocidad)
    /**
     * Constructor para crear autos de la marca Ford
     * @param modelo
     * @param color
     */
    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    //métodos
    //son bloques de código que definen el comportamiento de los objetos (acciones)
    void acelerar(){
        velocidad += 10;
    }

    void frenar(){
        velocidad -= 10;
    }

    //sobrecarga de métodos
    void acelerar(int kilometros){
        velocidad += kilometros;
    }

    /**
     * Si el nitro es true, se incrementa el doble de kilómetros a la velocidad
     * @param kilometros = es la cantidad a acelerar
     * @param nitro = true si tiene nitro, false si no tiene
     */
    void acelerar(int kilometros, boolean nitro){
        if(nitro) velocidad += kilometros * 2;
        else velocidad += kilometros;
    }

    void frenar(int kilometros){
        if(velocidad-kilometros<0) velocidad = 0;
        else velocidad -= kilometros;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    int obtenerVelocidad(){
        return velocidad;
    }

    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", velocidad=" + velocidad + "]";
    }

    // @Override
    // public String toString(){
    //     return "El auto es un " + marca + ", modelo " + modelo
    //                             + ", color " + color + " y tiene una velocidad de "
    //                             + velocidad + "Km/h.";
    // }

    


}
