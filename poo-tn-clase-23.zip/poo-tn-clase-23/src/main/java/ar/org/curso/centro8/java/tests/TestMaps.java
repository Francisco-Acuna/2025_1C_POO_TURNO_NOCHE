package ar.org.curso.centro8.java.tests;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class TestMaps {
    public static void main(String[] args) {
        /*
        Interface Map
        La interfaz Map permite representar un diccionario o una estructura de datos 
        de pares clave-valor. En un Map, cada clave (key) se asocia a un valor (value), 
        y las claves no tienen por qué ser números ni consecutivas; pueden ser de cualquier 
        tipo de objeto (por ejemplo, String, Integer, etc.). Esto permite representar 
        relaciones o asociaciones en las que el "índice" es una clave arbitraria.

        Aspectos importantes:
        - Un Map no extiende de Collection; aunque forma parte del framework de Collections, 
        es una interfaz independiente.
        - Cada clave es única dentro del mapa; si se agrega un valor con una clave ya existente, 
        se reemplaza el valor anterior.
        - A partir de JDK 8, Map incorpora un método forEach que recibe un BiConsumer (una 
        expresión lambda que acepta la clave y el valor) para recorrer de forma automática 
        todos sus pares.
        - Aunque Map no implementa la interfaz Stream, es posible obtener streams a partir de 
        sus vistas: keySet(), values() o entrySet().
        */ 
        
        System.out.println("**Interfaz Map**");

        Map<String, String> mapaSemana;
        //Map<key, value>
        //no se pueden poner como key ni value, tipos de datos primitivos

        // mapaSemana = new HashMap<>();
        // mapaSemana = new LinkedHashMap<>();
        mapaSemana = new TreeMap<>();

        //HashMap implementa un mapa sin ningún orden garantizado, es una de las implementaciones
        //más eficientes para operaciones de inserción y búsqueda

        //LinkedHashMap mantiene el orden de inserción, por lo que permite recorrer el mapa
        //en el orden en que se agregaron los elementos

        //TreeMap implementa NavigableMap y SortedMap. Ordena las claves según su orden natural
        //o mediante un Comparator. Para ello, requiere que las claves implementen la interfaz
        //Comparable, es similar a como funciona TreeSet

        //con el método .put() agregamos elementos
        mapaSemana.put("lu", "lunes");
        mapaSemana.put("ma", "martes");
        mapaSemana.put("mi", "miércoles");
        mapaSemana.put("ju", "jueves");
        mapaSemana.put("vi", "viernes");
        mapaSemana.put("sa", "sábado");
        mapaSemana.put("do", "domingo");
        //se pueden repetir los valores, pero no las llaves

        //con el método .get() obtengo un elemento
        System.out.println(mapaSemana.get("mi"));

        System.out.println("\nRecorrido de mapaSemana:");
        mapaSemana.forEach((k,v) -> System.out.println(k + " -> " + v));
        

    }
}
