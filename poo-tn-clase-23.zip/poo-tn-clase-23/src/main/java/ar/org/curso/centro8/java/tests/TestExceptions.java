package ar.org.curso.centro8.java.tests;

public class TestExceptions {
    public static void main(String[] args) {

        // System.out.println(10/0);
        // System.out.println("Esta línea no se va a ejecutar");

        //Manejo de excepciones
        //estructura try-catch-finally -> mecanismo para el manejo de excepciones

        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que pueden lanzar una Exception
             * Si no se produce ningún error, el bloque se ejecuta normalmente y salta al bloque
             * del finally (si es que existe).
             * Si se lanza una Exception, la ejecución del bloque try se detiene inmediatamente
             * y se transfiere el control al bloque del cacth
             */
        } catch (Exception e) { //obligatorio
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception
             * Se captura la excepción mediante un objeto del tipo Exception que contiene información
             * sobre el error. 
             * El programa continúa su ejecución después de este bloque, sin deternerse abruptamente.
             * Salta al bloque finally, si es que existe.
             */
        } finally { //opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no
             * una excepción.
             * Se utiliza para liberar recursos o realizar tareas de limpieza, como cerrar archivos,
             * conexiones a BD, etc.
             * Las variables declaradas dentro de los bloques try y catch no son accesibles en este
             * bloque, ya que el alcance (scope) es local a esos bloques
             */
        }

        //estas sentencias se ejecutan siempre
        //el programa finaliza normalmente.

    }
}
