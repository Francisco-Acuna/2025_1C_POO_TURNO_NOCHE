import java.util.Scanner;

public class Clase01 {
    public static void main(String[] args) {
        
        /*
         * Instituto: Centro de Formación Profesional N°8
         * Curso: Programación Orientada a Objetos
         * Lenguaje: Java
         * Cursada: Lunes, miércoles y viernes de 19 a 22.20hs.
         * Profesor: Francisco Acuña 
         * Email: franciscoacuna.centro8@gmail.com
         * Repositorio: https://github.com/Francisco-Acuna/2025_1C_POO_TURNO_NOCHE
         * Softwares necesarios: 
         *                  JDK (sugerido el 21) -> https://www.oracle.com/java/technologies/downloads/#jdk21-windows
         *                  Visual Studio Code -> https://code.visualstudio.com/
         *                  Extension de VSC -> Extension Pack for Java (by Microsoft)
         *                  MySQL y Workbench -> https://dev.mysql.com/downloads/installer/ 
         */

        //comentarios en línea

        /*
         * comentarios
         * en bloque
         * se puede escribir en varias líneas
         */

        /**
         * Comentarios
         * JavaDoc
         * Se puede escribir en varias líneas
         *  Se define antes de las clases o métodos
         */ 

        //etiquetas en los comentarios
        
        //TODO: indica tareas pendientes por implementar o finalizar

        //FIXME: indica errores o problemas que deben ser corregidos

        //instalar extensión Todo Tree de Gruntfunggly (para comentarios
        //TODO y FIXME)

        //impresión por consola
        System.out.println("Hola Mundo!"); //esto es una sentencia

        //ctrl + k + ctrl + s  -> atajos de teclado

        //declaración de variable
        int variable; //declaración con tipo de dato e identificador
        variable = 10; //asignación de valor a la variable
        int variable2 = 20; //declaración y asignación de valor en línea
        int variable3=30, variable4=40, variable5=50; //declaración y asignación múltiple

        /*
         * Java es un lenguaje fuertemente tipado, por lo cual se deben respetar
         * ciertos lineamientos:
         * No se puede asignar otro tipo de dato como valor a una variable ya declarada.
         * No se puede cambiar el tipo de dato a una variable ya declarada.
         * No se puede crear otra variable con el mismo nombre.
         * Una variable puede tener una única declaración.
         * Una variable puede tener innumerables valores, siempre que sean 
         * del mismo tipo de dato.
         */

        //** Tipos de datos primitivos **
        
        //byte - ocupa 1 byte y representa un entero entre -128 y 127
        byte variableByte = 100;
        System.out.println(variableByte);

        //short - ocupa 2 bytes y representa un número entero entre -32.768 y 32.767
        short variableShort = 5614;
        System.out.println(variableShort);

        //int - ocupa 4 bytes y representa un número entero entre -2.147.483.648 y 2.147.483.647
        int variableInt = 1516516131;
        System.out.println(variableInt);

        //long - ocupa 8 bytes y representa un número muy grande entero entre
        //-2 elevado a la 63 y 2 elevado a la 63 -1
        long variableLong = 135_265_656_269L;
        System.out.println(variableLong);

        //float - ocupa 4 bytes y tiene alrededor de 6-7 dígitos de precisión total
        float variableFloat = 1235.23f;
        System.out.println(variableFloat);

        //double - ocupa 8 bytes y tiene alrededor de 15-16 dígitos de precisión total
        double variableDouble = 1235.23;
        System.out.println(variableDouble);

        //boolean - almacena solo 2 valores (verdadero o falso)
        boolean variableBoolean = true;
        System.out.println(variableBoolean);

        //char - ocupa 2 bytes y almacena un número entero que representa
        //un caracter de la tabla unicode
        //UNICODE es un estandard de codificación de caracteres a nivel mundial
        char variableChar = 65;
        System.out.println(variableChar);
        variableChar = 'F';
        System.out.println(variableChar);

        //String - no es un tipo de dato primitivo
        //es una clase que representa una cadena de caracteres
        String variableString = "Hola Mundo!";
        System.out.println(variableString);

        //tipos de datos VAR (inferencia de tipos)
        //aparecen a partir del JDK 10
        //No es un tipo de datos en sí mismo. Es una palabra clave del lenguaje
        //que indica al compilador que infiera el tipo de dato a partir de la 
        //primera asignación de valor.
        var var1 = 100; //int
        var var2 = 12.5; //double
        var var3 = 12.5f; //float
        var var4 = 'c'; //char
        var var5 = "c"; //String
        var var6 = true; //boolean
        //este tipo de datos solo puede ser utilizado en variables locales.
        //No puede ser usado como parámetro de método ni como atributo de clase.
        //No se pueden declarar un var sin asignar su valor

        //** Concatenación de cadenas **

        //operador de concatenación +
        String nombre = "Micaela";
        System.out.println("Hola " + nombre + "!");

        //método String.format()
        //permite formatear cadenas
        int edad = 24;
        String mensaje = String.format("Hola, mi nombre es %s y tengo " + 
                                        "%d años", nombre, edad);
        System.out.println(mensaje);
        /*
        Marcadores de posición:
         * %s -> cadenas de texto
         * %d -> números enteros
         * %f -> números con decimales
         * %n -> saltos de línea
         */

        //método System.out.printf()
        //se utiliza para imprimir directamente con formato
        System.out.printf("Hola, mi nombre es %s y tengo %d años", 
                            nombre, edad);

        //** Operadores **

        //Operadores aritméticos
        /*
         * + suma
         * - resta
         * * multiplicación
         * / división
         * % módulo o resto de la división
         * Son operadores binarios porque necesitan de dos operandos.
         * Los operandos son numéricos, y el resultado es numérico.
         */

        //Operadores de asignación
        /*
          * =  asignación
           += suma y asignación
           -= resta y asignación
           *= multiplicación y asignación
           /= división y asignación
           %= resto y asignación.
           Son operadores binarios.
           Asignar el valor a una variable y de la modifican utilizando una expresión. 
        */

        //Operadores incrementales y decrementales
        /*
           * ++ incrementa en 1 el valor de la variable
           * -- decrementa en 1 el valor de la variable
           * Puede utilizarse de dos maneras:
           * Prefijo (++x ó --x): la variable se modifica antes de que se use 
           * su valor en la expresión
           * Postfijo (x++ ó x--): la variable se modifica después de que se use
           * su valor en la expresión.
           * Son operadores unarios, trabajan con un solo operador.
        */

        //Operadores relacionales
        /*
         * >  mayor
         * <  menor
         * >= mayor o igual
         * <= menor o igual
         * == igual
         * != distinto
         * Son operadores binarios.
         * Los operandos son numéricos y el resultado es booleano.
         */

        //Operadores lógicos
        /*
         * && AND (y lógico)
         * || OR (o lógico)
         * !  NOT (negación)
         * Los operandos son booleanos.
         * El resultado es booleano.
         */

        /*
         * Un solo operador lógico & ó | evalúa ambas condiciones.
         * Al utilizar dos && ó || 
         */

        //*** Estructuras ***

        //** condicionales **

        //if
        int numero1 = 10;
        int numero2 = 20;

        if(numero1>numero2) System.out.println("El número1 es mayor que el número2");
        //si solo se ejecuta una sentencia dentro del if, se puede hacer en línea

        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
            int suma = numero1 + numero2;
            System.out.println("La suma de ambos números es " + suma);
        }
        //cuando ejecutamos más de una sentencia, debemos escribir
        //el cuerpo del if, en bloque

        //if-else
        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
            System.out.println("Se ejecutan varias sentencias por bloque");
        }else{
            System.out.println("El número1 no es mayor que el número2");
            System.out.println("Se ejecutan varias sentencias por bloque");
        }

        //if-else en cascada (if-else if-else)
        if(numero1>numero2){
            System.out.println("El número1 es mayor que el número2");
        } else if(numero1<numero2){
            System.out.println("El número1 es menor que el número2");
        } else{
            System.out.println("Ambos números son iguales.");
        }

        //if-else anidado
        boolean tienePasaporte = true;
        if(tienePasaporte){
            if (edad >= 18) {
                System.out.println("Puede viajar solo");
            }else{
                System.out.println("Debe viajar acompañado");
            }
        }else{
            System.out.println("No puede viajar.");
        }

        //operador ternario (if-else abreviado)
        mensaje = (edad>=18) ? "Mayor de edad" : "Menor de edad";
        System.out.println(mensaje);

        //estructura switch
        int dia = 5;

        switch (dia) {
            case 1: System.out.println("Lunes"); break;
            case 2: System.out.println("Martes"); break;
            case 3: System.out.println("Miércoles"); break;
            case 4: System.out.println("Jueves"); break;
            case 5: System.out.println("Viernes"); break;
            case 6: System.out.println("Sábado"); break;
            case 7: System.out.println("Domingo"); break;
            default: System.out.println("No es un día válido");
        }

        switch(dia){
            case 1,2,3,4,5: System.out.println("Es día de semana");
            case 6,7: System.out.println("Es fin de semana");
            default: System.out.println("No es un día válido");
        }

        //rule switch (JDK 14)
        //se reemplazan los : por las -> y desaparecen los break
        //además se puede utilizar la estructura como una expresión
        String diaSemana = switch(dia){
            case 1 -> "Lunes";
            case 2 -> "Martes";
            case 3 -> "Miércoles";
            case 4 -> "Jueves";
            case 5 -> "Viernes";
            case 6 -> "Sábado";
            case 7 -> "Domingo";
            default -> "No es un día válido";
        };

        System.out.println(diaSemana);

        //** Estructuras repetitivas **

        //while
        int contador = 1;
        while(contador<=10){
            System.out.println(contador);
            contador++;
        }

        //do-while con break y continue
        int numero = 0;
        int suma = 0;
        Scanner teclado = new Scanner(System.in);

        System.out.println("Se sumarán los números enteros, pares, positivos ingreados");
        System.out.println("Siempre y cuando la suma no supere los 100");
        do{
            System.out.println("Ingrese un número para suma o el 0 para salir");
            numero = teclado.nextInt();
            if(numero%2 != 0) continue;
            if(numero > 0) suma += numero;
            if(suma > 100) break;
        } while (numero!=0);
        System.out.println("La suma de los números enteros pares positivos, " 
                            + "es de " + suma);

        //for
        for(int i=0; i<=5; i++){
            System.out.print("hola");
        }
            
        

    }
}
