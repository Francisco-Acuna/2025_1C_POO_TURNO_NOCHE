package ar.org.curso.centro8.java.entidades;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Auto implements Comparable{
    @EqualsAndHashCode.Include
    private String marca;
    private String modelo;
    private String color;

    @Override
    public int compareTo(Auto autoPara) {
        String thisAuto = this.getMarca() + "," + this.getModelo() + "," + this.getColor();
        String paraAuto = autoPara.getMarca() + "," + autoPara.getModelo() + "," + autoPara.getColor();
        return thisAuto.compareTo(paraAuto);
    }
}
