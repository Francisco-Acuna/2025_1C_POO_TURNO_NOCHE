package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.herencia.Cliente;
import ar.org.centro8.curso.java.entidades.herencia.Direccion;
import ar.org.centro8.curso.java.entidades.herencia.Empleado;
import ar.org.centro8.curso.java.entidades.herencia.Persona;
import ar.org.centro8.curso.java.entidades.objetos.Dato;
import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;

public class TestObjetos {
    public static void main(String[] args) {
        /*
         * En Java existe la clase Class. Java internamente, toma a todas las clases que
         * nosotros creemos, como objetos de la clase Class.
         * Los atributos son tratados en Java como objetos de la clase Field, que se
         * encuentra en el paquete java.lang.reflect.Field
         * Los métodos son tratados por Java como objetos de la clase Method que se
         * encuentra en el paquete java.lang.reflect.Method
         * Esta es la base del API de reflexión de Java, la cual nos permite inspeccionar
         * y manipular información de clases, atributos y métodos en tiempo de ejecución.
         * Aunque nosotros no creamos los objetos de Field ni de Method directamente, el
         * compilador y la JVM generan estos objetos internamente para gestionar la
         * información de nuestras clases.
         */

        Direccion direccion1 = new Direccion("Medrano", 162, "2", "aula 8");
        Cuenta cuenta1 = new Cuenta(124, "Libras esterlinas");
        Persona persona1 = new Empleado("Juan", "Fernandes", 50, direccion1, 125, 600000);
        Persona persona2 = new Cliente("Mariano", "Molina", 20, direccion1, 85, cuenta1);

        System.out.println(persona1);
        System.out.println(persona2);

        System.out.println(persona1.getNombre());
        // System.out.println(persona1.getSueldoBasico(); getSueldoBasico() no está definido en Persona
        
        // Empleado empleado1 = (Empleado) persona1;

        int nro1 = 100;
        long nro2 = nro1;
        long nro3 = 1000;
        // int nro4 = nro3; error no puedo guardar un entero dentro de un long

        Empleado empleado1 = (persona1 instanceof Empleado) ? (Empleado) persona1 : null;

        //los objetos tienen acceso a los miembros de su clase más todo lo heredado de
        //la clase padre y de la clase Object (clase padre de todas las clases).
        //El objeto de la clase padre, no puede tener acceso a miembros de las clases hijas

        //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        Dato d1 = new Dato(2);
        Dato d2 = d1;
        Dato d3 = new Dato(d1.getDato());
        Dato d4 = new Dato(2);
        String st = "2";

        //el método hashCode() es un método heredado de la clase Object
        System.out.println("d1.hashCode():" + d1.hashCode());
        System.out.println("d2.hashCode():" + d2.hashCode());
        System.out.println("d3.hashCode():" + d3.hashCode());
        System.out.println("d4.hashCode():" + d4.hashCode());
        System.out.println("st.hashCode():" + st.hashCode());
        //el código hash es un valor entero calculado por Java a partir del estado
        //o la identidad del objeto. Este valor se utiliza principalmente en estructuras
        //de datos hash para facilitar la búsqueda y el almacenamiento eficiente de objetos.
        //No es la dirección de memoria del objeto.

        //el método equals() también está definido en Object
        //compara objetos por medio de su hashCode, devuelve un booleano.
        System.out.println("\n======================\n");
        System.out.println("d1.equals(d1): " + d1.equals(d1)); //true
        System.out.println("d1.equals(d2): " + d1.equals(d2)); //true
        System.out.println("d1.equals(d3): " + d1.equals(d3)); //false
        System.out.println("d1.equals(d4): " + d1.equals(d4)); //false
        System.out.println("d1.equals(st): " + d1.equals(st)); //false

        //vamos a sobreescribir los métodos equals() y hashCode()

        //===============================================================

        System.out.println("**Clase String**");

        //tiene varios constructores
        String texto = "Cadena de texto";
        String texto2 = new String("Hola");

        //comparación de Strings
        //al comparar un objeto String con el operador == va a comparar que sean el mismo
        //objeto en memoria
        System.out.println(texto2 == "Hola"); // false
        //para compararlo a nivel estado, utilizamos equals()
        System.out.println(texto2.equals("Hola")); //true

        //StringBuilder y StringBuffer

        //inicializamos un String vacío
        String cadena = "";

        // for (int i = 1; i < 500000; i++) {
        //     cadena += "x";
        // }
        // System.out.println(cadena);

        //StringBuilder es la más rápida, pero no es sincronizada, es ideal para 
        //desarrollos en entornos de un solo hilo.
        //StringBuffer es sincronizada, lo que la hace un poco más lenta, pero 
        //soporta el multiproceso.
        StringBuilder sb;
        StringBuffer sf;

        sb = new StringBuilder();
        sf = new StringBuffer();

        for (int i = 1; i < 500000; i++) {
            sf.append("x");
        }
        System.out.println(sf);

        


    }

}
