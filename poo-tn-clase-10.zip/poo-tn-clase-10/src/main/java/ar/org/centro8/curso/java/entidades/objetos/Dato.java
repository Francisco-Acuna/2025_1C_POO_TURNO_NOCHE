package ar.org.centro8.curso.java.entidades.objetos;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class Dato {
    private int dato;

/*     @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + dato;
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Dato other = (Dato) obj;
        if (dato != other.dato)
            return false;
        return true;
    } */

    

}
