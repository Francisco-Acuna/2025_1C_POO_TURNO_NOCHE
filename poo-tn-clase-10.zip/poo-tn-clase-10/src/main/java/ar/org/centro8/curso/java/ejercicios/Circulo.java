package ar.org.centro8.curso.java.ejercicios;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Circulo extends FiguraGeometrica{

    //atributos
    private double radio;

    /**
     * Método deprecado por el Profesor Francisco por considerarse inseguro.
     */
    @Deprecated
    public Circulo(){}

    @Override
    public double getPerimetro(){
        return radio * Math.PI * 2;
    }

    @Override
    public double getSuperficie(){
        return Math.pow(radio, 2) * Math.PI;
    }


}
