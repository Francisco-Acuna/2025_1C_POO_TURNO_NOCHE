package ar.org.centro8.curso.java.ejercicios;

import lombok.Setter;
import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Rectangulo extends FiguraGeometrica{
    //atributos
    private double lado1;
    private double lado2;
    
    @Override
    public double getPerimetro(){
        return (lado1 + lado2) * 2;
    }

    @Override
    public double getSuperficie(){
        return lado1 * lado2;
    }


}
