package ar.org.centro8.curso.java.entidades.herencia;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class Empleado extends Persona{
    private int legajo;
    private float sueldoBasico;


    public Empleado(String nombre, String apellido, int edad, Direccion direccion, int legajo, float sueldoBasico) {
        super(nombre, apellido, edad, direccion);
        this.legajo = legajo;
        this.sueldoBasico = sueldoBasico;
    }

    @Override
    public void saludar() {
        System.out.println("Hola, mi nombre es " + super.getNombre() + ", y soy un empleado!");
    }



}
