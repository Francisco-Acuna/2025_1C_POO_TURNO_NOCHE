package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.keywords.Automovil;

public class TestKeywords {
    public static void main(String[] args) {
        //creamos un objeto de la clase Automovil
        Automovil auto1 = new Automovil("Chevrolet", "Spin", "Blanco");
        System.out.println(auto1);
        System.out.println(auto1.getVelocidad());
        auto1.acelerar(10);
        System.out.println(auto1.getVelocidad());

        Automovil auto2 = new Automovil("Fiat", "Argo", "Verde");
        System.out.println(auto2);
        System.out.println(auto2.getVelocidad());
        auto2.acelerar(20);
        System.out.println(auto2.getVelocidad());
        System.out.println(auto1.getVelocidad());

        //los miembros estáticos se utilizan sin necesidad de crear un objeto de la clase
        System.out.println(Automovil.getVelocidad());
        Automovil.acelerar(100);
        System.out.println(auto1.getVelocidad());
        System.out.println(auto2.getVelocidad());
        System.out.println(Automovil.getVelocidad());


    }
}
