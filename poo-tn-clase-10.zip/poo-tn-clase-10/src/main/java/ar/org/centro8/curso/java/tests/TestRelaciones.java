package ar.org.centro8.curso.java.tests;

import java.util.List;

import ar.org.centro8.curso.java.entidades.relaciones.Auto;
import ar.org.centro8.curso.java.entidades.relaciones.ClienteMayorista;
import ar.org.centro8.curso.java.entidades.relaciones.ClienteMinorista;
import ar.org.centro8.curso.java.entidades.relaciones.Cuenta;
import ar.org.centro8.curso.java.entidades.relaciones.EmpleadoAgregaciones;
import ar.org.centro8.curso.java.entidades.relaciones.EmpleadoAsociacionSimple;
import ar.org.centro8.curso.java.entidades.relaciones.EmpleadoComposicion;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("** Test de la clase Cuenta **");
        
        Cuenta cuenta1 = new Cuenta(1, "pesos argentinos");
        System.out.println(cuenta1);
        cuenta1.depositar(100000);
        cuenta1.depositar(10000);
        System.out.println(cuenta1.getSaldo());

        Cuenta cuenta2 = new Cuenta(2, "dólares");
        cuenta2.depositar(20000);
        cuenta2.debitar(30000);
        System.out.println(cuenta2.getSaldo());

        System.out.println("** Clase Cuenta funcionando correctamente **");

        System.out.println();

        System.out.println("** Test de la clase ClienteMinorista");

        ClienteMinorista clienteMinorista1 = new ClienteMinorista(1, "Oscar", "Aleman", cuenta1);
        System.out.println(clienteMinorista1); 
        // clienteMinorista1.depositar(250000); error, el método depositar no es de la
        //clase ClienteMinorista, pertenece a la clase Cuenta
        clienteMinorista1.getCuenta().depositar(250000);
        System.out.println(clienteMinorista1.getCuenta().getSaldo());

        //creamos un apuntador
        //un apuntador es una referencia, no ocupa más lugar de memoria
        Cuenta cta = clienteMinorista1.getCuenta();
        cta.debitar(225000);
        System.out.println(cta.getSaldo());

        System.out.println("** Clase ClienteMinorista funcionando correctamente **");

        System.out.println();

        System.out.println("** Test de ClienteMayorista **");

        ClienteMayorista clienteMayorista1 = new ClienteMayorista(15, "Coroner", "Av. Saenz 459");
        System.out.println(clienteMayorista1);

        //creamos un apuntador para facilitar el manejo de las cuentas
        List<Cuenta> cuentas = clienteMayorista1.getCuentas();

        //con el método add() agregamos cuentas a la lista
        cuentas.add(cuenta2);
        Cuenta cuenta3 = new Cuenta(152, "libras esterlinas");
        cuentas.add(cuenta3);
        cuentas.add(new Cuenta(8787, "Reales"));

        for(Cuenta c:cuentas) System.out.println(c);

        cuentas.get(0).depositar(10000);
        System.out.println(cuentas.get(0).getSaldo());

        Cuenta cuentaFavoritaDeAlejo = cuentas.get(2);
        //ejemplo de cómo generar un apuntador para tener un identificador
        //de la cuenta creada dentro de la lista

        System.out.println(cuentaFavoritaDeAlejo);

        System.out.println("** Clase ClienteMayorista funcionando correctamente **");

        System.out.println("===============================");

        System.out.println("\n** Test de clase Auto **");

        Auto auto1 = new Auto("Peugeot", "206", "Fucsia");
        System.out.println(auto1);
        System.out.println(auto1.getColor());
        auto1.setColor("negro");
        System.out.println(auto1.getColor());

        System.out.println("** Clase Auto funcionando correctamente **");

        System.out.println();

        System.out.println("** Test clase EmpleadoAsociacionSimple **");
        EmpleadoAsociacionSimple empleado1 = new EmpleadoAsociacionSimple(15, "Osvaldo", "Civile");
        System.out.println(empleado1);
        empleado1.usarAuto(auto1);
    
        System.out.println("** Clase EmpleadoAsociacionSimple funcionando correctamente **");

        System.out.println();

        System.out.println("** Test clase EmpleadoAgregaciones **");

        Auto auto2 = new Auto("Citroën", "C4", "Azul cobalto");

        EmpleadoAgregaciones empleado2 = new EmpleadoAgregaciones(152, "Javier", "Malosetti");
        System.out.println(empleado2);
        empleado2.setAuto(auto2);
        System.out.println(empleado2.getAuto());

        System.out.println("** Clase EmpleadoAgregaciones funcionando correctamente **");

        System.out.println();

        System.out.println("** Test clase EmpleadoComposicion **");

        EmpleadoComposicion empleado3 = new EmpleadoComposicion(65465, "Nicko", "McBrian", auto2);
        System.out.println(empleado3);

        EmpleadoComposicion empleado4 = new EmpleadoComposicion(45, "Jhonn", "Fogerty", "Renault", "Doce", "Blanco");
        System.out.println(empleado4);


    }
}
