package ar.org.centro8.curso.java.tests;

import java.util.Scanner;

import ar.org.centro8.curso.java.interfaces.I_Archivo;

public class TestInterfaces {
    public static void main(String[] args) {
        //creamos una referencia a la interfaz
        I_Archivo archivo;

        //inicialización
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese una oración:");
        String mensaje = teclado.nextLine();
        System.out.println("Seleccione en qué tipo de archivo quiere guardar su texto");
        System.out.println("TEXTO - BINARIO - NUBE");
        String opcion = teclado.nextLine();
        teclado.close();
        // el método close() de la clase Scanner sirve para liberar los recursos que
        //se utilizan para leer por consola. Este método es útil cuando son grandes
        //desarrollos. 

        archivo = I_Archivo.crearArchivo(opcion);

        archivo.setText(mensaje);
        archivo.info();
        System.out.println(archivo.getTipo());
        System.out.println(archivo.getText());
        archivo.mostrarTextoFormateado();



    }
}
