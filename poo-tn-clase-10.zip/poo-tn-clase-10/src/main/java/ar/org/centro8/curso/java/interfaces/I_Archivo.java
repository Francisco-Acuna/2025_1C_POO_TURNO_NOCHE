package ar.org.centro8.curso.java.interfaces;

import ar.org.centro8.curso.java.interfaces.implementaciones.ArchivoBinario;
import ar.org.centro8.curso.java.interfaces.implementaciones.ArchivoNube;
import ar.org.centro8.curso.java.interfaces.implementaciones.ArchivoTexto;

public interface I_Archivo {
    /*
     * Interfaces en Java
     * No tienen constructores, no se pueden crear objetos de una interfaz.
     * Todas las variables declaradas en un interfaz son implícitamente public,
     * static y final.
     * Puede tener métodos abstractos.
     * Por defecto, los métodos de una interfaz son públicos, pero a partir de Java 9
     * se pueden definir métodos privados para uso interno.
     * Los métodos, en una interfaz son por defecto abstractos y no tienen cuerpo, las
     * clases que lo implementen deben ponerle el cuepro al método. Pero a partir de
     * Java 8 se pueden definir los métodos default y estáticos que sí incluyen 
     * implementación. Ese código es compartido por todas las clases que implementen
     * la interfaz. Estas clases pueden además sobreescribir estos métodos.
     * Una clase puede implementar varias interfaces.
     * Como una clase puede implementar todas las interfaces que desee, se genera un
     * comportamiento similar a lo que sería una herencia múltiple, pero sin serlo.
     * La herencia múltiple no existe en Java.
     */

    //no hace falta escribir las palabras public y abstract, por defecto son así
    /**
     * Método para escribir en el archivo.
     * @param texto : texto a escribir
     */
    void setText(String texto);

    /**
     * Método para leer un archivo.
     * @return el texto del archivo.
     */
    String getText();

    /**
     * Método que retorna, en forma de cadena, el tipo de archivo.
     * @return
     */
    String getTipo();

    default void info(){
        System.out.println("I_Archivo: Interfaz para la gestión de archivos. Define el "
                            + "comportamiento común para todas las implementaciones.");
    }

    //Factory Methods (métodos de fábrica)
    //Permiten centralizar la creación de instancias de las clases que implementan la
    //interfaz. Esto sirve para ocultar la lógica de instanciación y decidir, en función
    //de los parámetros, qué instancia devolver.
    public static I_Archivo crearArchivo(String tipo){
        switch(tipo.toLowerCase()){
            case "texto": return new ArchivoTexto();
            case "binario": return new ArchivoBinario();
            case "nube": return new ArchivoNube();
            default: throw new IllegalArgumentException("Tipo de archivo no soportado: " + tipo); 
        }
    } 
    //esto es polimorfismo por interfaces

    //ejemplo de métodos privados dentro de la interfaz
    //los métodos privados permiten reutilizar código interno.

    //método default que valida y muestra un texto formateado
    default void mostrarTextoFormateado(){
        String texto = getText();
        if(esTextoValido(texto)){
            System.out.println("Texto formateado: " + formatearTexto(texto));
        }else {
            System.out.println("El texto no es válido");
        }
    }

    private boolean esTextoValido(String texto){
        return texto != null && !texto.trim().isBlank();
    };

    private String formatearTexto(String texto){
        return texto.trim().toUpperCase();
    }



}
