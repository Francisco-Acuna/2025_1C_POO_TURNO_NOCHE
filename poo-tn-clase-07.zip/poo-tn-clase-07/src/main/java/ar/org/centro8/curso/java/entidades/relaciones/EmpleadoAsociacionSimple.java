package ar.org.centro8.curso.java.entidades.relaciones;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class EmpleadoAsociacionSimple {
    //La Asociación simple es la menos acoplada, la reconocemos con las palabras 
    //usa un/a. En este caso un empleado usa un auto

    private int legajo;
    private String nombre;
    private String apellido;

    public void usarAuto(Auto auto){
        System.out.println("El empleado está usando el auto " + auto);
    }


}
