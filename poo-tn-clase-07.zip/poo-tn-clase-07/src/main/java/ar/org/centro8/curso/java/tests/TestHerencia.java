package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.herencia.Direccion;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia:
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extensión y especialización de comportamientos.
         * La reconocemos con las palabras "es un/a".
         * Representa la relación más fuerte entre clases.
         * En este caso, las clases pueden derivar de otras clases.
         * La clase derivada es una subclase y la clase de la que deriva es la superclase.
         * También se las conoce como clase hija y clase padre.
         * Una clase en Java solo puede tener una herencia directa.
         * Java no soporta la herencia múltiple.
         */

        System.out.println("** Test de la clase Direccion **");

        Direccion direccion1 = new Direccion("Av. Córdoba", 2135, "1", "sala 3");
        System.out.println(direccion1);
        


    }
}
