package ar.org.centro8.curso.java.ejercicios;

import lombok.Setter;
import lombok.ToString;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@Setter
@AllArgsConstructor
@ToString
public class Rectangulo {
    //atributos
    private double lado1;
    private double lado2;
    
    public double getPerimetro(){
        return (lado1 + lado2) * 2;
    }

    public double getSuperficie(){
        return lado1 * lado2;
    }


}
