package ar.org.curso.centro8.java.entidades;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@AllArgsConstructor
@ToString
// @EqualsAndHashCode(onlyExplicitlyIncluded = true)
@EqualsAndHashCode
public class Auto implements Comparable<Auto>{
    // @EqualsAndHashCode.Include
    private String marca;
    private String modelo;
    private String color;

    /*
     * El método compareTo define el orden natural de una clase que implemente Comparable<T>
     * El orden natural es la forma determinada de comparar instancias.
     * Valor de retorno:
     *      devuelve un valor menor a 0 si this es menor que el elemento que entra como parámetro
     *      devuelve 0 si son iguales
     *      devuelve un valor mayor a 0 si this es mayor que el elemento que entra como parámetro
     * Para invertir el orden natural, le agregamos el signo - al return
     */
    @Override
    public int compareTo(Auto autoPara) {
        String thisAuto = this.getMarca() + "," + this.getModelo() + "," + this.getColor();
        String paraAuto = autoPara.getMarca() + "," + autoPara.getModelo() + "," + autoPara.getColor();
        return thisAuto.compareTo(paraAuto);
    }
    //el código propuesto tiene fácil interpretación y mantenimiento pero no es performante,
    //hay mejores formas de poder escribir lo mismo y las estudiaremos más adelante
}
