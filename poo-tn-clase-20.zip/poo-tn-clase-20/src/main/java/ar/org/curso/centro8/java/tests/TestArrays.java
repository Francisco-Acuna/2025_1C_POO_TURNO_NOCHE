package ar.org.curso.centro8.java.tests;

import ar.org.curso.centro8.java.entidades.Auto;

public class TestArrays {
    public static void main(String[] args) {
        //Arrays
        /*
         * Un array es una estructura de datos en Java que permite almacenar múltiples
         * valores del mismo tipo de datos en una ubicación contínua de memoria.
         * Se utiliza cuando se necesita manejar un conjunto fijo de elementos relacionados.
         */

         Auto[] autos;
         //en este array solo se podrán guardar objetos del tipo Auto

        autos = new Auto[4];
        //la longitud del arreglo es de 4, esto quiere decir que solo se van a poder
        //almacenar, 4 elementos. O sea, 4 objetos del tipo Auto.
        //Los arrays son estáticos, esto significa que no lo puedo agrandar ni achicar.
        //Si necesito otro tamaño de arreglo, lo tengo que eliminar y volver a crear.

        //los arreglos tienen un proceso de inicialización automático
        //los tipos de dato referenciados se inicializan en null
        for (int i = 0; i < autos.length; i++) {
            System.out.println(autos[i]);
        }

        //los tipos de dato numéricos, se inicializan en 0
        int[] numeros = new int[4];
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }

        //inicializar manualmente al vector
        autos[0] = new Auto("Fiat", "Palio", "Verde");
        autos[1] = new Auto("VW", "Gol", "Blanco");
        autos[2] = new Auto("Renault", "Clio", "Rojo");
        autos[3] = new Auto("Fiat", "Uno", "Gris");

        //para mostrar los elementos de un vector
        // System.out.println(autos[0]);
        //utilizamos un recorrido por índices
        for(int i=0; i<autos.length; i++) System.out.println(autos[i]);

        //a partir del JDK 5 aparece la estructura for-each
        //en este caso, no existe la palabra reservada for-each, si no que es el mismo
        //for que se comporta como un for-each
        for(Auto auto:autos) System.out.println(auto);
        //esto significa que de la colección de autos, por cada auto, de la clase Auto
        //voy a imprimir cada elemento (instancia de Auto)
        //El for-each funciona tanto con Arrays como con colecciones que implementan
        //la interfaz Iterable
        //No sirve para agregar ni eliminar elementos.
        //No tiene acceso al índice

    }
}
