package ar.org.curso.centro8.java.tests;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;
import java.util.TreeSet;

import ar.org.curso.centro8.java.entidades.Auto;

public class TestCollection {
    public static void main(String[] args) {
        //List
        /*
         * La interfaz List representa una lista con índices que emula a un vector.
         * List es la única que tiene métodos definidos con índices.
         * ArrayList es una lista del tipo vector o Array que se diferencia por no ser 
         * estática, en este caso, la lista es dinámica.
         * LinkedList tiene el comportamiento heredado de List, internamente utiliza
         * una lista enlazada.
         * La clase Vector implementa List, pero no son los vectores que hemos estudiado
         * anteriormente. Es una colección que internamente utiliza la tecnología de
         * vectores. No se recomienda su uso en la actualidad, por ser una tecnología
         * en desuso, con código antiguo y poco performante, tiene una sincronización que
         * la vuelve muy lenta.
         * ArrayList es una lista tipo vector o Array, LinkedList es una lista enlazada.
         * Diferencia:
         * ArrayList es más veloz para recorrer elementos.
         * LinkedList es más veloz para agregar y eliminar elementos.
         */

        List lista;

        lista = new ArrayList();

        //el método .add() me permite agregar elementos.
        lista.add(new Auto("Peugeot", "308", "Negro"));
        lista.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        lista.add("hola");
        lista.add(83);
        lista.add(23.45);

        //recorrido de una lista
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(lista.get(i)); //el método get obtiene el elemento de la lista
        }
        //el método size() devuelve la longitud de la lista

        //el método remove() elimina un elemento de la lista
        lista.remove(3);

        //recorrido con for-each
        for(Object elemento:lista) System.out.println(elemento);

        //Iterable
        /*
         * Iterable es el padre de todas las interfaces en el framework Collections.
         * Dentro de Iterable se encuentra definido el método default foreach.
         * Este método realiza un recorrido. La idea es que no tengamos nosotros que 
         * realizar una estructura de repetición, si no que sea la misma lista la
         * que se autorrecorra. Es una forma de escribir código más moderna y aparece 
         * a partir del JDK 8.
        */

        System.out.println("\nRecorrido foreach()");
        lista.forEach(item->System.out.println(item));
        /*
         el método foreach() recibe un objeto del tipo Consumer que define qué operación
         se ejecutará sobre cada elemento de la colección.
         Consumer es una interfaz funcional cuyo propósito es "consumir" un valor.
         Representa una operación que recibe un argumento del tipo "T" y no devuelve nada.
         T es un tipo de dato genérico.
         Generalmente se implementa una expresión Lambda (Lambda Expression)
         Las Lambdas Expression son funciones anónimas que aparecen a partir del JDK 8.
         Una función anónima es una porción de código (una función) que no tiene nombre
         y se define en el sitio donde se va a usar.
         Se utiliza para simplificar código.         
        */

        //si quisiéramos utilizar más de una sentencia en el bloque, tenemos que abrir llaves
        lista.forEach(item -> {
            System.out.println(item);
            System.out.println("-");
        });

        //Method References (referencia de métodos)
        System.out.println("\nRecorrido con foreach simplificado");
        //si vamos a escribir una única sentencia, podemos omitir el uso del iterador
        lista.forEach(System.out::println);
        //con el operador 4 puntos :: le estamos indicando a Java que el ítem implícito
        //lo coloque como argumento del método

        System.out.println("\n** ListIterator **\n");
        /*
         * ListIterator es una interfaz especializada para recorrer colecciones que implementan
         * List. A diferencia del Iterator, o del método forEach simple de Iterable, ListIterator
         * ofrece funcionalidades adicionales:
         * - Recorrido bidireccional: permite avanzar y retroceder sobre las listas
         * - Tiene acceso a índices
         * - Permite eliminar, reemplazar y agregar elementos durante la iteración
         */

         List nombres = new ArrayList();
         nombres = new LinkedList<>();

         nombres.add("Ricardo");
         nombres.add("Jenny");
         nombres.add("Carlos");
         nombres.add("Ana");
         nombres.add("Marcela");

         //Obtenemos el ListIterator de la la lista nombres
         ListIterator<String> li = nombres.listIterator();

        //recorrido hacia adelante
        System.out.println("\n**Recorrido hacia adelante**");
        while(li.hasNext()) { //hasNext() devuelve un booleano que indica si hay un siguiente elemento
            int indice = li.nextIndex(); //devuelve el siguiente índice
            String nombre = li.next(); //devuelve el siguiente elemento
            System.out.println("Índice: " + indice + " : " + nombre);
        }

        //recorrido hacia atrás
        System.out.println("\n**Recorrido hacia atrás**");
        while(li.hasPrevious()){
            int indice = li.previousIndex(); // índice anterior
            String nombre = li.previous(); //elemento anterior
            System.out.println("Índice:" + indice + " : " + nombre);
        }

        //reemplazar elementos
        System.out.println("\n**Reemplazar elementos**");
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Carlos")) li.set("David"); //reemplaza Carlos por David
        }

        System.out.println("Lista de nombres después de reemplazar a Carlos por David: " + nombres);

        //agregar elementos
        System.out.println("\n**Agregar elementos**");
        //reiniciar la posición del cursor
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Ana")) li.add("Juan");
        }

        System.out.println("Lista de nombres después de agregar a Juan luego de Ana: " + nombres);

        //eliminar elementos
        System.out.println("\n**Eliminar elementos**");
        li = nombres.listIterator();
        while(li.hasNext()){
            String nombre = li.next();
            if(nombre.equals("Jenny")) li.remove(); //elimina el elemento actual ("Jenny")
        }

        System.out.println("Lista de nombres después de eliminar a Jenny: " + nombres);
        System.out.println();

        //========================
        //      Generics
        //========================
        /*Para especificar el tipo de datos de una lista, lo hacemos a través de los Generics
        Los Generics aparecieron en Java a partir del JDK 5 y son una característica que
        permite crear clases, interfaces o métodos con tipos de datos parametrizados.        
        */

        // List<Auto> lista2 = new ArrayList<>();
        List<Auto> lista2 = new LinkedList();
        //No pueden crearse colecciones de tipos de datos primitivos, en su lugar se deben 
        //utilizar los wrappers, por ej. int -> Integer, double -> Double, char -> Character

        lista2.add(new Auto("Renault", "Clio", "Rojo"));
        // lista2.add("Hola"); //error no puedo agregar cualquier elemento

        Auto auto1 = (Auto) lista.get(0);
        Auto auto2 = lista2.get(0);

        //Vamos a copiar los autos de la lista a lista2
        lista.forEach(item -> {
            if(item instanceof Auto){
                lista2.add((Auto) item);
            }
        });

        //recorremos la lista2
        System.out.println("\n**Recorrido de lista2:");
        lista2.forEach(System.out::println);

        System.out.println("\n*****************************************");

        System.out.println("\n** Interface Set **");

        /*
         * La interface Set implementa Collection y tiene 3 implementaciones.
         * La interface Set provee una lista sin índices. 
         * El mismo objeto contenido en la lista es el índice. 
         * No admite valores duplicados. 
         */

        // HashSet
        // Es la más veloz de todas las implementaciones. No garantiza un orden específico.

        Set<String> setSemana;

        // setSemana = new HashSet<>();
        // setSemana = new LinkedHashSet<>();
        setSemana = new TreeSet<>();

        //agregar los días de la semana
        setSemana.add("lunes");
        setSemana.add("lunes");
        setSemana.add("martes");
        setSemana.add("miércoles");
        setSemana.add("jueves");
        setSemana.add("jueves");
        setSemana.add("viernes");
        setSemana.add("sábado");
        setSemana.add("domingo");
        setSemana.add("domingo");

        System.out.println("\nContenido de setSemana:");
        setSemana.forEach(System.out::println);

        //LinkedHashSet
        /*
         * Es otra implementación de Set. Por lo tanto no permite valores duplicados y no hay índices.
         * No es tan rápida como HashSet. Almacena los elementos en una lista enlazada, esto quiere
         * decir que cuando recorremos las lista vamos a ver a los elementos por orden de entrada. 
        */

        //TreeSet
        /*
         * La clase TreeSet implementa SortedSet que extiende de Set.
         * Al usar TreeSet, la clase del Generic debe implementar la interfaz Comparable.
         * Es una implementación que almacena en un árbol por orden natural.
         * Esto quiere decir que los elementos van a aparecer ordenados. En este caso, al
         * ser del tipo String, van a estar ordenados alfabéticamente. 
         * No vamos a necesitar un código de ordenamiento específico. 
        */

        //creamos un Set de autos
        Set<Auto> setDeAutos;

        // setDeAutos = new LinkedHashSet<>();
        // setDeAutos = new HashSet<>();
        setDeAutos = new TreeSet<>();
        //TreeSet implementa SortedSet que extiende de Set. El SortedSet requiere que la clase
        //del Generic implemente Comparable.

        //agregamos los autos de la lista2 al setDeAutos
        //lista2.forEach(setDeAutos::add);
        //sería lo mismo que hacer lo siguiente:
        //lista2.forEach(auto -> setDeAutos.add(auto));
        //podemos utilizar un método definido en la interfaz Collection
        setDeAutos.addAll(lista2);

        System.out.println("\nContenido de setDeAutos:");
        setDeAutos.forEach(System.out::println);

        setDeAutos.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        setDeAutos.add(new Auto("Chevrolet", "2Corsa", "Rojo"));
        setDeAutos.forEach(System.out::println);

        System.out.println();

        // System.out.println("\nRecorrido con hashCode:");
        // setDeAutos.forEach(item -> System.out.println(item + "\t" + item.hashCode()));

        setDeAutos.add(new Auto("Chevrolet", "Corsita", "Rojo"));
        setDeAutos.forEach(System.out::println);

        //==========================================================================

        //Interfaz Queue

        /*
         * La interfaz Queue define operaciones FIFO (cola)
         * La interfaz Deque es una "double-ended-queue", y define operaciones FIFO (cola) y
         * LIFO (pila).
         * FIFO -> First In First Out -> primero en entrar, primero en salir
         * LIFO -> Last In First Out -> último en entrar, primero en salir
         * 
         * Implementaciones:
         * ArrayDeque -> es una implementación eficiente para colas estándard donde se encolan
         * elementos en la parte de atrás y se desencolan por la parte de adelante. ArrayDeque
         * puede también establecer un comportamiento de LIFO (pila) de acuerdo a los métodos que
         * esté invocando.
         * PriorityQueue -> organiza los elementos basándose en su orden natural o mediante un
         * Comparator, lo que permite manejar prioridades, en este caso, el orden de extracción
         * puede no coincidir con el orden de inserción.
         * LinkedList -> también implementa Queue, a través de la interfaz Deque, y puede usarse
         * para representar una cola, aunque ArrayDeque suele ser la preferida por su rendimiento.
         * 
         * Implementaciones de Queue y cuándo utilizarlas:
         * ArrayDeque -> cola/pila eficiente no sincronizada. Crecimiento dinámico.
         * LinkedList -> cola/pila más lenta en acceso aleatorio, pero versátil.
         * PriorityQueue -> cola con prioridades, no garantiza ordenamiento completo al iterar
         * ArrayBlockingQueue y LinkedBlockingQueue cola con capacidad limitada y bloqueantes,
         * pero con concurrencia.
         */

        System.out.println("\n**Interfaz Queue**\n");

        Queue<Auto> colaAutos;

        // colaAutos = new ArrayDeque<>();
        colaAutos = new PriorityQueue<>();

        /*
         * PriorityQueue permite almacenar elementos en forma que el elemento con mayor prioridad
         * (según el orden natural o un Comparator definido) siempre se encuentre en la cabeza
         * de la cola. La prioridad se define ya sea mediante el orden natural de los elementos
         * (por ejemplo, si implementan Comparable) o mediante un objeto Comparator que se pase 
         * al momento de la creación.
         * En su implementación interna, garantiza que el primer elemento sea siempre el de mayor
         * prioridad, según el criterio definido. Pero el resto de la estructura, no se encuentra
         * completamente ordenada. Solo se garantiza el orden relativo de la cabeza.
         * Al encolar elementos reorganiza internamente su estructura para mantener la propiedad
         * de que el menor elemento (o de mayor prioridad) esté en la raiz.
         * Al desencolar extrae el elemento de la cabeza. Cada extracción reordena su estructura
         * para colocar el siguiente elemento prioritario en la posición de la cabeza.
         * Al iterar sobre una PriorityQueue, el orden en el que se recorren los elementos, no es
         * necesariamente el orden natural o el orden de prioridades. El iterador recorre el arreglo
         * que no está completamente ordenado.
         */


        //el método .offer() permite encolar un elemento
        colaAutos.offer(auto1);
        colaAutos.offer(auto2);
        colaAutos.offer(new Auto("Ford", "Ecosport", "Blanca"));
        //existe también el método .add para agregar, la diferencia es en cómo trabaja internamente.
        //Si la colección del tipo cola está completa, el método add() lanza una excepción
        //offer() en cambio devuelve un valor booleano que dará false si no se pudo guardar el elemento,
        //sin lanzar una excepción.

        //Hay clases que implementan la interface Queue y representan estructuras de datos con 
        //una capacidad limitada.
        //ArrayBlockingQueue y LinkedBlockingQueue son muy comunes en aplicaciones concurrentes o en 
        //sistemas en donde se desee limitar el uso de la memoria.

        //agregar todos los autos de una lista:
        colaAutos.addAll(lista2);

        System.out.println("\n**colaAutos:**");
        colaAutos.forEach(System.out::println);

        //el método .size() permite obtener la longitud de la colección
        System.out.println("\nLongitud de la cola: " + colaAutos.size());

        //desencolamos los elementos. Lo hace desde el primero al último
        // el método .poll() desencola elementos. Los recupera y elimina
        System.out.println("\nEliminando elementos...");
        while(!colaAutos.isEmpty()){
            System.out.println(colaAutos.poll());
        }
        //el método remove() hace lo mismo, pero si la cola está vacía
        //lanza una excepción, en cambio, poll() devuelve un null.

        // Deque<Auto> pilaAutos = new ArrayDeque<>();
        Stack<Auto> pilaAutos = new Stack<>();
        
        //el método .push() agrega un elemento al tope de la pila (apila)
        pilaAutos.push(new Auto("Citroën", "C5", "Verde"));

        //agregamos toda la colección
        pilaAutos.addAll(lista2);

        pilaAutos.push(new Auto("Ford", "Fiesta", "Blanco"));

        //recorremos la lista
        System.out.println("\npilaAutos:");
        pilaAutos.forEach(System.out::println);

        // el métodos size() devuelve la longitud de la lista
        System.out.println("\nLongitud de pila: " + pilaAutos.size());

        //el método .pop() elimina elementos de la pila (desapila)
        System.out.println("\nEliminando elementos de la pila...");
        while(!pilaAutos.isEmpty()){
            System.out.println(pilaAutos.pop());
        }

        System.out.println("\nLongitud de pila: " + pilaAutos.size());

        //Clase Stack
        /*
         * Representa una pila en Java
         * Es una clase que hereda de Vector.
         * Vector es una clase histórica de Java que implementa un vector o arreglo dinámico
         * de dimensión extensible mediante la incorporación de nuevos elementos. 
         * En versiones más recientes se prefiere utilizar ArrayList para los vectores, aunque
         * Vector sigue vigente.
         * Stack es una lista con índices.
         * Stack implementa la funcionalidad de una pila (LIFO).
         * Aunque la clase sigue vigente, en el desarrollo moderno ,se recomienda utilizar 
         * implementaciones de Deque, como ArrayDeque, para representar pilas, ya que ofrece
         * una mayor eficiencia y una API más actualizada.
         */

        //ver comportamiento de stack.

        //=============================================================================

        // pasar un array a una colección

        String[] nombresArray = {"Ana", "Luis", "Maria"};
        List<String> listaNombres = Arrays.asList(nombresArray);
        //crea una vista fijada ("backed") sobre el array (backed significa que existe
        //una misma área de almacenamiento subyacente)
        //La List resultante tiene tamaño fijo, no se pueden utlizar los métodos add() ni remove()
        //Si se modifica un elemento de listaNombres, también cambia en nombresArray y viceversa

        List<String> listaInmutable = List.of("Ana", "Luis", "Maria");
        //crea una lista inmutable, de tamaño fijo. No permite ni add(), ni remove(), ni set().
        //Tampoco cambia si el array original se modifica.

        List<String> listaNueva = new ArrayList<>();
        Collections.addAll(listaNueva, nombresArray);
        //añade todos los elementos del array a la colección de destino
        //la lista resultante es mutable, se pueden insertar y eliminar elementos

        //pasar a otro tipo de colecciones
        //a Set
        Set<String> conjunto = new HashSet<>(Arrays.asList(nombresArray));

        //a Queue
        Queue<String> cola = new LinkedList(Arrays.asList(nombresArray));

        //a Dequeue
        Deque<String> deque = new ArrayDeque(Arrays.asList(nombresArray));


    }
}
