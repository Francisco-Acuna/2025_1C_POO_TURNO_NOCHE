package ar.org.curso.centro8.java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTnClase20Application {

	public static void main(String[] args) {
		SpringApplication.run(PooTnClase20Application.class, args);
	}

}
