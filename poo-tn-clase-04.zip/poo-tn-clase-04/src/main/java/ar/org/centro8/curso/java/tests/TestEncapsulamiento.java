package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.encapsulamiento.Empleado;
import ar.org.centro8.curso.java.entidades.encapsulamiento.EmpleadoL;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        
        //creamos un objeto de la clase Empleado
        // Empleado empleado = new Empleado(); 
        //error porque no tiene definido un constructor vacío
        Empleado empleado1 = new Empleado(1, "Mario", "Sanchez", "Soltero", 500000);
        System.out.println(empleado1);

        //empleado1.nombre="Maria"; //error porque el atributo nombre
        //es privado, por lo tanto, no tengo acceso
        empleado1.setNombre("María");
        System.out.println(empleado1.getNombre());

        Empleado empleado2 = new Empleado(2, "Jorge", "Mendoza", "Casado");
        System.out.println(empleado2);

        //construimos un objeto de la clase EmpleadoL
        EmpleadoL empleado3 = new EmpleadoL(12, "Carlos", "García", "Casado");
        System.out.println(empleado3);

        empleado3.setNombre("Mike");
        System.out.println(empleado3.getNombre()); 

        System.out.println(empleado3.getSueldoBasico());
        empleado3.setSueldoBasico(1500000);

    }
}

