package ar.org.centro8.curso.java.entidades.encapsulamiento;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
 * Lombok
 * es una librería para Java que reduce código repetitivo al generar automáticamente
 * en tiempo de compilación algunas partes comunes de las clases
 */

@Getter //genera los getters de todos los atributos
@Setter //genera los setters de todos los atributos
@AllArgsConstructor //genera el constructor completo
//@NoArgsConstructors -> genera el constructor vacío
//@RequiredArgsConstructors -> permite crear un constructor que no tenga 
//todos los atributos como parámetros. Solo va a incluir a los atributos
//que sean final o que estén declarados con @NonNull
@ToString //genera el toString()
/*
 * @Data
 * sirve para evitar tener que crear la anotación de cada funcionalidad
 * por separado.
 * Genera automáticamente:
 * Getters para todos los campos
 * Setters para todos los campos
 * Método toString()
 * Métodos equals() y hashCode()
 * Un constructor requerido (similar al @RequiredArgsConstructor) que incluye
 * todos los campos finales o aquellos marcados con @NonNull
 */
public class EmpleadoL {
    //atributos
    private int id;
    private String nombre;
    private String apellido;
    private String estadoCivil;
    //de esta manera le indicamos que el atributo no tendrá getter ni setter
    //de los generados automáticamente
    // @Getter(AccessLevel.NONE)
    // @Setter(AccessLevel.NONE)
    private double sueldoBasico;


    public EmpleadoL(int id, String nombre, String apellido, String estadoCivil) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.estadoCivil = estadoCivil;
        this.sueldoBasico = 750000;
    }


    public double getSueldoBasico(){
        return sueldoBasico / 2;
    }

    public void setSueldoBasico(double sueldoBasico){
        System.out.println("El sueldo debe ser declarado luego en el SIGE");
        this.sueldoBasico = sueldoBasico;
    }


}
