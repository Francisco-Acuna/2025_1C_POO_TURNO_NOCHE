package ar.org.centro8.curso.java.tests;

import ar.org.centro8.curso.java.entidades.varargs.Cliente;
import ar.org.centro8.curso.java.entidades.varargs.Factura;

public class TestVarargs {
    public static void main(String[] args) {
        /*
         * varargs (argumentos variables)
         * aparecieron a partir del JDK 5
         * sirven para crear métodos que permitan variar la cantidad de parámetros que reciben
         */

        Cliente cliente1 = new Cliente("Guillermo");

        Factura factura1 = new Factura(1);
        Factura factura2 = new Factura(2);
        Factura factura3 = new Factura(3);
        Factura factura4 = new Factura(4);
        Factura factura5 = new Factura(5);

        // cliente1.agregarFactura(factura1);
        // cliente1.agregarFactura(factura2);

        cliente1.agregarFacturas(factura1);
        System.out.println(cliente1);

        //cuando hay varios parámetros en un método, el argumento variable debe ir
        //a lo último. Solo puede haber un único argumento variable como parámetro de un método

    }
}
