package ar.org.centro8.curso.java.entidades.varargs;

import lombok.AllArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@ToString
public class Factura {
    private int numero;
}
