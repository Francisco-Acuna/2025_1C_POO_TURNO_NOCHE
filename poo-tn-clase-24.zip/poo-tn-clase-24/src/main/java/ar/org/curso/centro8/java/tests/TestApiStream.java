package ar.org.curso.centro8.java.tests;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import ar.org.curso.centro8.java.entidades.Persona;

public class TestApiStream {
    public static void main(String[] args) {
        //API Stream (JDK 8)
        /*
         * Permite procesar flujos de datos de manera uniforme, independientemente de la fuente
         * (archivos, BD, web service, etc.), usando un enfoque declarativo con expresiones
         * Lambdas.
         * API (Application Programming Interface): Conjunto de métodos e interfaces que 
         * facilitan el acceso a funcionalidades sin conocer su implementación interna.
         */

        List<Persona> personas = new ArrayList<>();
        personas.add(new Persona(1, "Ana", 32));
        personas.add(new Persona(2, "Javier", 41));
        personas.add(new Persona(3, "Carlos", 22));
        personas.add(new Persona(4, "Estela", 55));
        personas.add(new Persona(5, "Raul", 27));
        personas.add(new Persona(6, "Miguel", 37));
        personas.add(new Persona(7, "Monica", 47));
        personas.add(new Persona(8, "Marcela", 57));
        personas.add(new Persona(9, "Ricardo", 67));
        personas.add(new Persona(10, "Juan", 45));
        personas.add(new Persona(11, "Juan", 23));

        //select * from personas;
        personas.forEach(System.out::println);

        //Stream provee métodos para filtrar
        //el método stream() devuelve una implementación de la interface Stream
        //el método filter() permite sobreescribir un predicado de expresión Lambda
        //(un predicado es una interface funcional que define una condición que un objeto
        //determinado, debe cumplir)

        //select * from personas where nombre = "Ana";
        System.out.println("\nselect * from personas where nombre = \"Ana\";");
        personas
                .stream() //devuelve una secuencia de elementos para procesarlos (no guarda los elementos)
                .filter(p->p.getNombre().equals("Ana")) //obtenemos un objeto del tipo Persona, luego va la
                //expresión booleana, si arroja true, es parte de los resultados, si arroja false, no es parte
                //de los resultados
                .forEach(System.out::println); //filter devuelve un stream con todos los registros

        
        System.out.println("\nselect * from personas where nombre=\"Ana\" or nombre=\"Juan\"");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Ana") || p.getNombre().equals("Juan"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like 'ja%'");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("ja"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like \'%a\'");
        personas    
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre like '%ar%';");
        personas
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("ar"))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where edad >= 30;");
        personas        
                .stream()
                .filter(p->p.getEdad()>=30)
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where nombre='Juan' and edad>=30;");
        personas
                .stream()
                .filter(p->p.getNombre().equals("Juan") && p.getEdad()>=30)
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        /*
        La interfaz Comparator permite definir criterios de comparación entre objetos, es decir,
        especifica como se debe ordenar un conjunto de elementos. No se trata de ordenar según
        el orden natural de los objetos como lo haría la interfaz Comparable, si no de definir
        un criterio personalizado para compararlos.
         */        

        System.out.println("\nselect * from personas order by edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre, edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .thenComparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by nombre desc, edad;");
        personas
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre)
                .reversed()
                .thenComparing(Persona::getEdad))
                .forEach(System.out::println);

        System.out.println("\nselect * from personas order by id;");
        personas
                .stream()
                .sorted(Comparator.comparingInt(Persona::getId)) //mejora la performance para int
                .forEach(System.out::println);

        System.out.println("\nselect * from personas where edad between 30 and 40 order by nombre;");
        personas
                .stream()
                .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);

        System.out.println("\nselect max(edad) from personas;");
        int edadMaxima = 
                        personas
                                .stream()
                                .max(Comparator.comparingInt(Persona::getEdad))
                                .get()
                                .getEdad();
        //max devuelve un objeto del tipo Optional, no devuelve una lista, contiene una persona
        //o sea, un objeto del tipo Persona con la mayor edad.
        //con get obtenemos el valor del objeto Optional, es decir, obtengo el objeto Persona
        //con el objeto persona, obtengo su edad, con getEdad()

        System.out.println("\nselect * from personas where edad=(select max(edad) from personas);");
        personas
                .stream()
                .filter(p->p.getEdad() == (
                        personas
                                .stream()
                                .max(Comparator.comparingInt(Persona::getEdad))
                                .get()
                                .getEdad()      
                ))
                .forEach(System.out::println);


        personas
                .stream()
                .filter(p->p.getEdad() == edadMaxima)
                .forEach(System.out::println);


        //uso de .map() y reduce() con stream
        //.map() es una operación intermedia que transforma los elementos
        //.reduce() reduce todos los elementos a un único resultado

        //creamos un List de un arreglo, ese List es estático, no puede cambiar su tamaño
        List<Integer> numeros = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        //filtra por números pares, duplicarlos y sumarlos
        int suma = numeros
                        .stream() //creo un stream desde la lista
                        .filter(n -> n%2 == 0) // filtro por números pares
                        .map(n->n*2) //multiplica cada número por 2
                        .reduce(0, Integer::sum); //suma todos los elementos del stream y
                        //devuelve el resultado de esa suma
                        //en el caso de reduce() el 0 es el valor inicial del acumulador interno
                        //Integer::sum es la operación que va a realizar el acumulador 
                        //es lo mismo que (a,b) -> a + b
        System.out.println("\nLa suma del doble de los números enteros pares es de: " + suma);

    }
}
