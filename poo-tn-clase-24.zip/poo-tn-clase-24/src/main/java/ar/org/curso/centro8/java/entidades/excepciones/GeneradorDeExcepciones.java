package ar.org.curso.centro8.java.entidades.excepciones;

public class GeneradorDeExcepciones {
    //creamos los métodos estáticos para no tener que crear objetos de la clase para llamarlos
    //estos métodos van a lanzar excepciones

    public static void generar(){
        int[] vector = new int[5];
        vector[10] = 20;
    }

    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }

    public static void generar(String nro){
        Integer.parseInt(nro);  
    }

    public static void generar(String texto, int indice){
        System.out.println(texto.charAt(indice));
    }
}
