package ar.org.curso.centro8.java.entidades.excepciones;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class NoHayMasPasajesException extends Exception {
    //con esta clase, estamos creando una Exception que se va a lanzar en el caso
    //de que no existan los pasajes que hagan falta
    //para que esta clase sea un exception, tiene que extender de Exception
    //al extender de Exception es una checked Exception

    private String nombreVuelo;
    private int cantidadPasajes;
    private int cantidadInvalidaPasajes;

    //modificamos el toString() para tener el mensaje que recibirá el usuario al momento
    //de lanzarse esta excepción
    @Override
    public String toString(){
        return "El vuelo " + nombreVuelo + " no tiene " + cantidadInvalidaPasajes + " pasajes, " + 
        "solo tiene " + cantidadPasajes + " pasajes.";
    }
}
