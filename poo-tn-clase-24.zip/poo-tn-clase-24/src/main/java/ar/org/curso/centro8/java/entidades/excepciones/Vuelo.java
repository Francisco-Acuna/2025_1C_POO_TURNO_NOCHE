package ar.org.curso.centro8.java.entidades.excepciones;

import lombok.Getter;
import lombok.ToString;
import lombok.AllArgsConstructor;

@Getter
@AllArgsConstructor
@ToString
public class Vuelo {
    private String nombreVuelo;
    private int cantidadPasajes;

    public synchronized void venderPasajes(int cantidad) throws NoHayMasPasajesException{
        if(cantidad > cantidadPasajes) throw new NoHayMasPasajesException(nombreVuelo, cantidadPasajes, cantidad);
        cantidadPasajes -= cantidad;
    }

    /*
     * La cláusula throws se utiliza en la firma de un método para indicar que éste podria
     * lanzar una o más excepciones que no se manejan internamente. Es decir, se declara la 
     * posibilidad de que se produzca una excepción para que el código que llame a este método
     * sea consciente de ello y decida cómo manejarlo.
     * En Java, las checked Exceptions deben ser gestionadas. Si un método puede lanzar una
     * excepcion verificada y no la maneja dentro de un bloque try-catch, es obligatorio 
     * declararlo con throws para que el compilador sepa que quien invoque al método debe 
     * encargarse del manejo de la excepción.
     */
}
