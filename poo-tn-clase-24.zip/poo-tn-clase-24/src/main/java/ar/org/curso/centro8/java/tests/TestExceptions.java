package ar.org.curso.centro8.java.tests;

import java.io.File;
import java.io.FileInputStream;

import ar.org.curso.centro8.java.entidades.excepciones.GeneradorDeExcepciones;
import ar.org.curso.centro8.java.entidades.excepciones.Lector;
import ar.org.curso.centro8.java.entidades.excepciones.NoHayMasPasajesException;
import ar.org.curso.centro8.java.entidades.excepciones.Vuelo;

public class TestExceptions {
    public static void main(String[] args) {

        // System.out.println(10/0);
        // System.out.println("Esta línea no se va a ejecutar");

        //Manejo de excepciones
        //estructura try-catch-finally -> mecanismo para el manejo de excepciones

        try { //obligatorio
            /*
             * En este bloque se colocan todas las sentencias que pueden lanzar una Exception
             * Si no se produce ningún error, el bloque se ejecuta normalmente y salta al bloque
             * del finally (si es que existe).
             * Si se lanza una Exception, la ejecución del bloque try se detiene inmediatamente
             * y se transfiere el control al bloque del cacth
             */
        } catch (Exception e) { //obligatorio
            /*
             * En este bloque se definen las acciones a realizar cuando se produce una Exception
             * Se captura la excepción mediante un objeto del tipo Exception que contiene información
             * sobre el error. 
             * El programa continúa su ejecución después de este bloque, sin deternerse abruptamente.
             * Salta al bloque finally, si es que existe.
             */
        } finally { //opcional
            /*
             * Este bloque se ejecuta siempre, independientemente de que se haya lanzado o no
             * una excepción.
             * Se utiliza para liberar recursos o realizar tareas de limpieza, como cerrar archivos,
             * conexiones a BD, etc.
             * Las variables declaradas dentro de los bloques try y catch no son accesibles en este
             * bloque, ya que el alcance (scope) es local a esos bloques
             */
        }

        //estas sentencias se ejecutan siempre
        //el programa finaliza normalmente.

        //ejemplo:
        // try {
        //     System.out.println(10/0);
        //     System.out.println("Esta sentencia no se ejecuta en caso de haber excepción");
        // } catch (Exception e) {
        //     System.out.println("Bloque catch: se produjo un error");
        //     System.out.println(e);
        // } finally {
        //     System.out.println("Bloque finally: se ejecuta siempre");
        // }
        // System.out.println("Fuera del try-cath-finally: se ejecuta siempre");
        // System.out.println("El programa finaliza normalmente.");

        //uso del finally
        // String mensaje = "Hola Mundo!";
        // try {
        //     mensaje = "<ini>" + mensaje;
        //     return;
        // } catch (Exception e) {
        //     System.out.println(e);
        // } finally {
        //     mensaje += "<fin>";
        //     System.out.println(mensaje);
        // }
        
        //este método puede lanzar una excepción que es una Unchecked, por lo tanto, no tenemos
        //la obligación de controlarla
        //GeneradorDeExcepciones.generar();

        //las excepciones del tipo checked sí estamos obligados a controlarla, por ejemplo
        //FileInputStream in = new FileInputStream(new File("texto.txt"));
        // try {
        //     FileInputStream in = new FileInputStream(new File("texto.txt"));
        // } catch (Exception e) {
        //     // System.out.println(e); //imprime el objeto del error
        //     //System.out.println(e.getMessage()); //imprime el mensaje del error (mensaje corto de la descripción)
        //     // System.out.println(e.getLocalizedMessage()); //es igual a getMessage() pero con una devolución
        //     //traducida según la configuración regional, si es que fue sobreescrita
        //     // System.out.println(e.getCause()); //indica la causa de la excepción
        //     e.printStackTrace(); //imprime la traza de excepción
        // }

        //captura personalizada de excepciones
        // try {
        //     // GeneradorDeExcepciones.generar(true);
        //     // GeneradorDeExcepciones.generar("51f");
        //     GeneradorDeExcepciones.generar();
        //     // GeneradorDeExcepciones.generar("hola", 10);
        // } catch (ArithmeticException e) { System.out.println("Error de división por cero"); 
        // } catch (NumberFormatException e) { System.out.println("Error de formato de número incorrecto"); 
        // } catch (NullPointerException e) { System.out.println("Error de puntero nulo");
        // // } catch (ArrayIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        // // } catch (StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        // } catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");
        // } catch (IndexOutOfBoundsException e) { System.out.println("Índice fuera de rango");  
        // //multicatch aparece en JDK 7, permite capturar varios tipos de excepciones
        // //el operador | no es clásico operador lógico de or, es un operador que separa tipos de excepciones
        // } catch (Exception e) { System.out.println("Ocurrió un error inesperado");}

        //vamos a validar una regla de negocio para la venta de pasajes
        Vuelo vuelo1 = new Vuelo("AERO121", 100);
        // vuelo1.venderPasajes(10);
        //estamos obligados a manejar la excepción
        try {
            vuelo1.venderPasajes(10);
            vuelo1.venderPasajes(30);
            vuelo1.venderPasajes(20);
            vuelo1.venderPasajes(30);
            vuelo1.venderPasajes(20); //lanza la exception
            vuelo1.venderPasajes(30);
        } catch (NoHayMasPasajesException e) {
            System.out.println(e);
        } 
        System.out.println("vuelo1: " + vuelo1);

        
        //try with resources
        // FileInputStream in = null;
        // try {
        //     in = new FileInputStream(new File("texto.txt"));
        //     in.read();
        //     in.close();
        // } catch (Exception e) {
        //     // in.close();
        //     try {
        //         if(in != null) in.close();
        //     } catch (Exception ee) {
        //         System.out.println(ee);
        //     }
        // }

        //a partir del JDK7 aparece el try-with-resources
        //simplifica el manejo y liberación de recursos (como archivos, conexiones a base de datos, etc.)
        //El recurso a utilizar debe implementar la interfaz AutoCloseable o su subinterfaz Closeable

        //dentro de los parámetros puedo declarar objetos que implementen la interfaz Closeable
        try (FileInputStream in = new FileInputStream(new File("texto.txt"));){
            in.read();
        } catch (Exception e) {
            System.out.println(e);
        }
        //Cuando declaramos como parámetro objetos que implementan Closeable o AutoCloseable
        //Java se va a encargar de cerrarlos sí o sí, pase lo que pase.
        //De esta manera nos despreocupamos de cerrar los recursos closeables, no tenemos que 
        //utilizar un bloque finally, nos queda un código mucho más claro y limpio. Es de mejor
        //lectura para otros programadores y estamos utilizando buenas prácticas.

        //Ventajas de utilizar try-with resources contra el bloque finally
        //- menos líneas de código, mayor claridad
        //- evitar olvidarnos de cerrar algún recurso
        //- menos responsabilidad de realizar los cierres manuales
        //- los cierres deben ser en orden inverso.

        try (Lector lector = new Lector()) {
            if(true) throw new Exception();
            lector.leer();
        } catch (Exception e) {
            System.out.println(e);
        }




    }
}
